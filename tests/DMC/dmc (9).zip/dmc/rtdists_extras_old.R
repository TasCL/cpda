###############################################################################
##### Functions taken from rtdists to enable accuulator vectorized t0 #########
############  WILL NOT BE NECESSARY AFTER NEXT UPDATE OF RTDISTS ##############
############### NB: Use getAnywhere(name) for rtdists functions ###############
###############################################################################

#######  Standard model ----

make.r <- function (drifts, b, A, n_v, t0, st0 = 0, n, return.ttf=FALSE) 
{
    drifts[drifts < 0] <- 0
    starts <- matrix(runif(min = 0, max = A, n = n * n_v), nrow = n_v)
    ttf <- t0 + (b - starts)/drifts
    if (return.ttf) return(ttf)
    resp <- apply(ttf, 2, which.min)
    rt <- ttf[cbind(resp,1:n)]
    if (st0[1]>0) rt <- rt + runif(min = 0, max = st0[1], n = n)
    bad <- !is.finite(rt)
    if (any(bad)) {
        warning(paste(sum(bad), "infinite RTs removed and less than", 
            n, "rts returned"))
        resp <- resp[!bad]
        rt <- rt[!bad]
    }
    data.frame(rt = rt, response = resp)
}


rlba.norm <- function (n,A,b,t0,mean_v,sd_v,st0=0,posdrift=TRUE,return.ttf=FALSE) 
{
    if (any(b < A)) 
        stop("b cannot be smaller than A!")
    n_v  <- ifelse(is.null(dim(mean_v)), length(mean_v), dim(mean_v)[1])
    if (posdrift) 
        drifts <- matrix(rtnorm(n = n * n_v, mean = mean_v, sd = sd_v, 
            lower = 0), nrow = n_v)
    else drifts <- matrix(rnorm(n = n * n_v, mean = mean_v, sd = sd_v), 
        nrow = n_v)
    make.r(drifts = drifts, b = b, A = A, n_v = n_v, t0 = t0, st0 = st0, n = n,
      return.ttf=return.ttf)
}


dlba.norm.core <- function (t,A,b,mean_v,sd_v,posdrift=TRUE,robust=FALSE,nn) 
# like dlba_norm_core but t0 dealt with outside (removed from t), and
# default added to nn
{
  
  pnormP <- function (x, mean = 0, sd = 1, lower.tail = TRUE) 
    ifelse(abs(x) < 7, pnorm(x, mean = mean, sd = sd, lower.tail = lower.tail), 
      ifelse(x < 0, 0, 1))
  
  dnormP <- function (x, mean = 0, sd = 1) 
    ifelse(abs(x) < 7, dnorm(x, mean = mean, sd = sd), 0)

    if (robust) {
        pnorm1 <- pnormP
        dnorm1 <- dnormP
    }
    else {
        pnorm1 <- pnorm
        dnorm1 <- dnorm
    }
    if (posdrift) 
        denom <- pmax(pnorm1(mean_v/sd_v), 1e-10)
    else denom <- rep(1, nn)
    if (any(A < 1e-10)) {
        A_small <- A < 1e-10
        out_A <- pmax(0, ((b[A_small]/t[A_small]^2) * 
                            dnorm1(b[A_small]/t[A_small], 
            mean_v[A_small], sd = sd_v[A_small]))/denom[A_small])
        zs <- t[!A_small] * sd_v[!A_small]
        zu <- t[!A_small] * mean_v[!A_small]
        chiminuszu <- b[!A_small] - zu
        chizu <- chiminuszu/zs
        chizumax <- (chiminuszu - A[!A_small])/zs
        out_o <- pmax(0, (mean_v[!A_small] * (pnorm1(chizu) - 
            pnorm1(chizumax)) + sd_v[!A_small] * (dnorm1(chizumax) - 
            dnorm1(chizu)))/(A[!A_small] * denom[!A_small]))
        out <- numeric(nn)
        out[!A_small] <- out_o
        out[A_small] <- out_A
        return(out)
    }
    else {
        zs <- t * sd_v
        zu <- t * mean_v
        chiminuszu <- b - zu
        chizu <- chiminuszu/zs
        chizumax <- (chiminuszu - A)/zs
        return(pmax(0, (mean_v * (pnorm1(chizu) - pnorm1(chizumax)) + 
            sd_v * (dnorm1(chizumax) - dnorm1(chizu)))/(A * denom)))
    }
}


plba.norm.core <- function (t,A,b,mean_v,sd_v,posdrift=TRUE,robust=FALSE,nn) 
# like plba_norm_core but t0 dealt with outside (removed from t), and
# default added to nn
{
  
    pnormP <- function (x, mean = 0, sd = 1, lower.tail = TRUE) 
      ifelse(abs(x) < 7, pnorm(x, mean = mean, sd = sd, lower.tail=lower.tail), 
        ifelse(x < 0, 0, 1))
  
    dnormP <- function (x, mean = 0, sd = 1) 
      ifelse(abs(x) < 7, dnorm(x, mean = mean, sd = sd), 0)

    if (robust) {
        pnorm1 <- pnormP
        dnorm1 <- dnormP
    }
    else {
        pnorm1 <- pnorm
        dnorm1 <- dnorm
    }
    if (posdrift) 
        denom <- pmax(pnorm1(mean_v/sd_v), 1e-10)
    else denom <- 1
    if (any(A < 1e-10)) {
        A_small <- A < 1e-10
        out_A <- pmin(1, pmax(0, (pnorm1(b[A_small]/t[A_small], 
            mean = mean_v[A_small], sd = sd_v[A_small], 
            lower.tail = FALSE))/denom[A_small]))
        zs <- t[!A_small] * sd_v[!A_small]
        zu <- t[!A_small] * mean_v[!A_small]
        chiminuszu <- b[!A_small] - zu
        xx <- chiminuszu - A[!A_small]
        chizu <- chiminuszu/zs
        chizumax <- xx/zs
        tmp1 <- zs * (dnorm1(chizumax) - dnorm1(chizu))
        tmp2 <- xx * pnorm1(chizumax) - chiminuszu * pnorm1(chizu)
        out_o <- pmin(pmax(0, (1 + (tmp1 + tmp2)/A[!A_small])/denom[!A_small]), 
            1)
        out <- numeric(length(mean_v))
        out[!A_small] <- out_o
        out[A_small] <- out_A
        return(out)
    }
    else {
        zs <- t * sd_v
        zu <- t * mean_v
        chiminuszu <- b - zu
        xx <- chiminuszu - A
        chizu <- chiminuszu/zs
        chizumax <- xx/zs
        tmp1 <- zs * (dnorm1(chizumax) - dnorm1(chizu))
        tmp2 <- xx * pnorm1(chizumax) - chiminuszu * pnorm1(chizu)
        return(pmin(pmax(0, (1 + (tmp1 + tmp2)/A)/denom), 1))
    }
}


dlba.norm <- function (t, A, b, mean_v, sd_v, posdrift = TRUE, robust = FALSE) 
{
    nn <- length(t)
#     A <- rep(A, length.out = nn)
#     b <- rep(b, length.out = nn)
#     mean_v <- rep(mean_v, length.out = nn)
#     sd_v <- rep(sd_v, length.out = nn)
#     if (any(b < A)) # b cannot be smaller than A! 
#         return(rep(0,nn))
    tpos <- (t>0) & (b >= A)
    out <- numeric(length(t))
    out[tpos] <- dlba.norm.core(t = t[tpos], A = A[tpos], b = b[tpos], mean_v = mean_v[tpos], 
        sd_v = sd_v[tpos], posdrift = posdrift, robust = robust, nn = nn)
    out
}


plba.norm <- function (t, A, b, mean_v, sd_v, posdrift = TRUE, robust = FALSE) 
{
    nn <- length(t)
#     A <- rep(A, length.out = nn)
#     b <- rep(b, length.out = nn)
#     mean_v <- rep(mean_v, length.out = nn)
#     sd_v <- rep(sd_v, length.out = nn)
    tpos <- (t>0) & (b >= A)
    out <- numeric(length(t))
    out[tpos] <- plba.norm.core(t = t[tpos], A = A[tpos], b = b[tpos], mean_v = mean_v[tpos], 
        sd_v = sd_v[tpos], posdrift = posdrift, robust = robust, nn = nn)
    out
}


n1PDFfixedt0.norm=function(dt,A,b,mean_v,sd_v, 
                           posdrift=TRUE,robust = FALSE) 
# Generates defective PDF for responses on node= 1
# dt (decison time) is a matrix with length(mean_v) rows, one row for
# each accumulator to allow for different start times
{
  
  n_acc <- ifelse(is.null(dim(mean_v)),length(mean_v),dim(mean_v)[1])
  if (is.null(dim(dt))) dt <- matrix(rep(dt,each=n_acc),nrow=n_acc)
  if (!is.matrix(mean_v)) mean_v <- matrix(rep(mean_v,dim(dt)[2]),nrow=n_acc)
  if (!is.matrix(sd_v)) sd_v <- matrix(rep(sd_v,dim(dt)[2]),nrow=n_acc)
  if (!is.matrix(b)) b <- matrix(rep(b,dim(dt)[2]),nrow=n_acc)
  if (!is.matrix(A)) A <- matrix(rep(A,dim(dt)[2]),nrow=n_acc)

  dt[1,] <- dlba.norm(dt[1,],A=A[1,],b=b[1,],mean_v=mean_v[1,],sd_v=sd_v[1,],
                      posdrift=posdrift,robust=robust)
  if (n_acc>1) for (i in 2:n_acc)
    dt[1,] <- dt[1,]*(1-plba.norm(dt[i,],
      A=A[i,],b=b[i,],mean_v=mean_v[i,],sd_v=sd_v[i,],
      posdrift=posdrift,robust=robust))
  dt[1,]
}

################################################################################
############################ ADDITIONAL MODELS #################################
################################################################################

# IMPLEMENTED WITH standard t0
# LBA go failure
# LBA Dont know
# LBA 2 condence levels
# LBA Gamma non-decision (MR linear angle effects (AS) on shape)
# LBA Lognormal non-decision

#####################  LBA with go failure ----

rlba.normGF <- function(n,A,b,t0,mean_v,sd_v,gf=0,st0=0,posdrift=TRUE,return.ttf=FALSE) 
  # random function for LBA race with go failure.
{
    out <- rlba.norm (n=n,A=A,b=b,t0=t0,mean_v=mean_v,sd_v=sd_v,st0=st0,
      posdrift=posdrift,return.ttf=return.ttf)     
    if (return.ttf) return(out)
    names(out) <- c("RT","R")
    if (gf > 0) {
      is.gf <- as.logical(rbinom(dim(out)[1],1,gf))
      out$RT[is.gf] <- NA
      out$R[is.gf] <- 1
    }

    out
}


n1PDFGF <- function(dt,A,b,mean_v,sd_v,t0,gf=0,st0=0,
  distribution="norm",args.list=list(posdrift=TRUE),silent=TRUE)
# Generates defective PDF for responses on node=1, with go failure 
# dt (decison time) is a vector of times
{
  out <- numeric(length(dt))
  is.go <- !is.na(dt)

  out[is.go] <- (1-gf[1])*n1PDF(dt[is.go],A=A,b=b,t0=t0,mean_v=mean_v,sd_v=sd_v,st0=st0,
    distribution=distribution,args.list=args.list,silent=silent)
  
  out[!is.go] <- gf[1]
  
  out
}


# # Check go failure 
# n=1e5
# v=c(2,1); sd_v = c(1,1); B=c(1,1); A=c(2,2);t0=1; gf=.2
# b=A+B
# sim <- rlba.normGF(n=n,A=A,b=b,mean_v=v,sd_v=sd_v,t0=t0,gf=gf)
# par(mfrow=c(1,3))
# dns <- plot.cell.density(sim,C=1,xlim=c(0,4),save.density=TRUE)
# pc <- integrate(n1PDFGF,lower=0,upper=Inf,A=A,b=b,mean_v=v,sd_v=sd_v,t0=t0,gf=gf)$value/(1-gf)
# print(pc)
# dt=dns$correct$x
# d <- n1PDFGF(dt,A=A,b=b,mean_v=v,sd_v=sd_v,gf=gf,t0=t0)
# # red=black?
# plot(dns$correct$x,dns$correct$y,type="l")
# lines(dns$correct$x,d,col="red")
# dt=dns$error$x
# d <- n1PDFGF(dt,A=A[2:1],b=b[2:1],mean_v=v[2:1],sd_v=sd_v[2:1],gf=gf,t0=t0)
# plot(dns$error$x,dns$error$y,lty=2,type="l")
# lines(dns$error$x,d,col="red",lty=2)
# 
# # Check (effectively) single accumulator case 
# n=1e5
# v=c(2,-100); sd_v = c(1,1); B=c(1,1); A=c(2,2);t0=1; gf=.2
# b=A+B
# sim <- rlba.normGF(n=n,A=A,b=b,mean_v=v,sd_v=sd_v,t0=t0,gf=gf)
# par(mfrow=c(1,3))
# dns <- plot.cell.density(sim,C=1,xlim=c(0,7),save.density=TRUE)
# pc <- integrate(n1PDFGF,lower=0,upper=Inf,A=A,b=b,mean_v=v,sd_v=sd_v,t0=t0,gf=gf)$value/(1-gf)
# print(pc)
# dt=dns$correct$x
# d <- n1PDFGF(dt,A=A,b=b,mean_v=v,sd_v=sd_v,gf=gf,t0=t0)
# # red=black?
# plot(dns$correct$x,dns$correct$y,type="l")
# lines(dns$correct$x,d,col="red")
# 
# v=c(-100,2)
# sim <- rlba.normGF(n=n,A=A,b=b,mean_v=v,sd_v=sd_v,t0=t0,gf=gf)
# par(mfrow=c(1,3))
# dns <- plot.cell.density(sim,C=1,xlim=c(0,7),save.density=TRUE)
# pe <- integrate(n1PDFGF,lower=0,upper=Inf,A=A,b=b,mean_v=v,sd_v=sd_v,t0=t0,gf=gf)$value/(1-gf)
# print(pe)
# dt=dns$error$x
# d <- n1PDFGF(dt,A=A[2:1],b=b[2:1],mean_v=v[2:1],sd_v=sd_v[2:1],gf=gf,t0=t0)
# plot(dns$error$x,dns$error$y,lty=2,type="l")
# lines(dns$error$x,d,col="red",lty=2)

#####################  LBA with Dont Know response ----

rlba.DK <- function (n,A,b,d,t0,mean_v,sd_v,st0=0,posdrift=TRUE) 
  # response2: 1 = nominal, 2 = DK
{
    if (any(b < A)) 
        stop("b cannot be smaller than A!")
    n_v  <- ifelse(is.null(dim(mean_v)), length(mean_v), dim(mean_v)[1])
    if ( posdrift ) 
        drifts <- matrix(rtnorm(n = n * n_v, mean = mean_v, sd = sd_v, 
            lower = 0), nrow = n_v)
    else drifts <- matrix(rnorm(n = n * n_v, mean = mean_v, sd = sd_v), 
        nrow = n_v)
    drifts[drifts < 0] <- 0
    starts <- matrix(runif(min = 0, max = A, n = n * n_v), nrow = n_v)
    ttf <- (b - starts)/drifts
    resp <- apply(ttf, 2, which.min)
    looser <- resp; looser[resp==1] <- 2; looser[resp==2] <- 1
    rt <- ttf[cbind(resp,1:n)] # actaully decision time, add t0 later
    
    # looser evidence = decison time * looser drift
    le <- rt*drifts[cbind(looser,1:n)]+starts[cbind(looser,1:n)]
    resp2 <- rep(1,length(resp))
    resp2[le>d[looser]] <- 2 # DK response
    if ( !(st0[1]>0) ) rt <- rt + t0 else
      rt <- rt + t0 + runif(min = 0, max = st0[1], n = n)
    bad <- !is.finite(rt)
    if (any(bad)) {
        warning(paste(sum(bad), "infinite RTs removed and less than", 
            n, "rts returned"))
        resp <- resp[!bad]
        rt <- rt[!bad]
    }
    data.frame(rt = rt, response = resp, response2 = resp2)
}


# tmp <- rlba.DK(n=10,A=1,b=2,d=1,t0=.1,mean_v=c(1,0),sd_v=1,st0=0,posdrift=TRUE)
# 
# d=A=c(1,1); b=d+1; mean_v=c(1,0); sd_v=c(1,1)

n1PDFfixedt0.DK <- function(dt,A,b,d,mean_v,sd_v, 
                           r2="",posdrift=TRUE,robust = FALSE) 
# Generates defective PDF for responses on node= 1
# dt (decison time) is a matrix with length(mean_v) rows, one row for
# each accumulator to allow for different start times
{
  
  n_acc <- 2
  if (is.null(dim(dt))) dt <- matrix(rep(dt,each=n_acc),nrow=n_acc)
  if (!is.matrix(mean_v)) mean_v <- matrix(rep(mean_v,dim(dt)[2]),nrow=n_acc)
  if (!is.matrix(sd_v)) sd_v <- matrix(rep(sd_v,dim(dt)[2]),nrow=n_acc)
  if (!is.matrix(b)) b <- matrix(rep(b,dim(dt)[2]),nrow=n_acc)
  if (!is.matrix(d)) d <- matrix(rep(d,dim(dt)[2]),nrow=n_acc)
  if (!is.matrix(A)) A <- matrix(rep(A,dim(dt)[2]),nrow=n_acc)

  r2 <- rep(r2,length.out=dim(dt)[2])
  is.dk <- r2 =="DK"
  
#   D1b <- dlba.norm(dt[1,!is.dk],A=A[1,!is.dk],b=b[1,!is.dk],mean_v=mean_v[1,!is.dk],
#       sd_v=sd_v[1,!is.dk],posdrift=posdrift,robust=robust)
#   S2d <- (1-plba.norm(dt[2,!is.dk],A=A[2,!is.dk],b=d[2,!is.dk],
#       mean_v=mean_v[2,!is.dk],sd_v=sd_v[2,!is.dk],posdrift=posdrift,robust=robust))
# 
#   if ( any(!is.dk) ) dt[1,!is.dk] <- D1b*S2d
# 
#   D1b <- dlba.norm(dt[1,is.dk],A=A[1,is.dk],b=b[1,is.dk],mean_v=mean_v[1,is.dk],
#       sd_v=sd_v[1,is.dk],posdrift=posdrift,robust=robust)
#   D2b <- dlba.norm(dt[2,is.dk],A=A[2,is.dk],b=b[2,is.dk],mean_v=mean_v[2,is.dk],
#       sd_v=sd_v[2,is.dk],posdrift=posdrift,robust=robust)
# 
#   S1d <- (1-plba.norm(dt[1,is.dk],A=A[1,is.dk],b=d[1,is.dk],
#       mean_v=mean_v[1,is.dk],sd_v=sd_v[1,is.dk],posdrift=posdrift,robust=robust))
#   S1b <- (1-plba.norm(dt[1,is.dk],A=A[1,is.dk],b=b[1,is.dk],
#       mean_v=mean_v[1,is.dk],sd_v=sd_v[1,is.dk],posdrift=posdrift,robust=robust))
#   S2b <- (1-plba.norm(dt[2,is.dk],A=A[2,is.dk],b=b[2,is.dk],
#       mean_v=mean_v[2,is.dk],sd_v=sd_v[2,is.dk],posdrift=posdrift,robust=robust))
#   S2d <- (1-plba.norm(dt[2,is.dk],A=A[2,is.dk],b=d[2,is.dk],
#       mean_v=mean_v[2,is.dk],sd_v=sd_v[2,is.dk],posdrift=posdrift,robust=robust))
#   
#   if ( any( is.dk) ) dt[1, is.dk] <- D1b*(S2b-S2d) + D2b*(S1b-S1d)
  
  
  if ( any(!is.dk) ) dt[1,!is.dk] <- 
    dlba.norm(dt[1,!is.dk],A=A[1,!is.dk],b=b[1,!is.dk],mean_v=mean_v[1,!is.dk],
      sd_v=sd_v[1,!is.dk],posdrift=posdrift,robust=robust)*
    (1-plba.norm(dt[2,!is.dk],A=A[2,!is.dk],b=d[2,!is.dk],
      mean_v=mean_v[2,!is.dk],sd_v=sd_v[2,!is.dk],posdrift=posdrift,robust=robust))
  if ( any(is.dk) ) dt[1,is.dk] <- 
    dlba.norm(dt[1,is.dk],A=A[1,is.dk],b=b[1,is.dk],
      mean_v=mean_v[1,is.dk],sd_v=sd_v[1,is.dk],posdrift=posdrift,robust=robust)*
      ((1-plba.norm(dt[2,is.dk],A=A[2,is.dk],b=b[2,is.dk],
        mean_v=mean_v[2,is.dk],sd_v=sd_v[2,is.dk],posdrift=posdrift,robust=robust))-
       (1-plba.norm(dt[2,is.dk],A=A[2,is.dk],b=d[2,is.dk],
        mean_v=mean_v[2,is.dk],sd_v=sd_v[2,is.dk],posdrift=posdrift,robust=robust))) +
    dlba.norm(dt[2,is.dk],A=A[2,is.dk],b=b[2,is.dk],
      mean_v=mean_v[2,is.dk],sd_v=sd_v[2,is.dk],posdrift=posdrift,robust=robust)*
    ((1-plba.norm(dt[1,is.dk],A=A[1,is.dk],b=b[1,is.dk],
      mean_v=mean_v[1,is.dk],sd_v=sd_v[1,is.dk],posdrift=posdrift,robust=robust))-
     (1-plba.norm(dt[1,is.dk],A=A[1,is.dk],b=d[1,is.dk],
      mean_v=mean_v[1,is.dk],sd_v=sd_v[1,is.dk],posdrift=posdrift,robust=robust)))

  dt[1,]
}


n1PDF.DK <- function (t,r2,A,b,d,mean_v,sd_v,t0,st0=0,posdrift=TRUE,robust = FALSE)
  # r2 is second respond, d is dont know crierion
{
  dt <- pmax(t-t0[1], 0)
  if (st0[1] == 0) 
    return(n1PDFfixedt0.DK(dt,r2=r2,A=A,b=b,d=d,mean_v=mean_v,sd_v=sd_v, 
                              posdrift=posdrift,robust = robust))
    else {
      tmpf <- function(tau,ti0,r2,A,b,d,mean_v,sd_v,scale,shape) 
        n1PDFfixedt0.DK(tau,r2,A,b,mean_v,sd_v)/st0
    outs <- numeric(length(dt))
    for (i in c(1:length(outs))) {
      tmp <- try(integrate(f=tmpf,
        lower=0,upper=dt[i],ti0=dt[i],r2=r2[i],
        A=A,b=b,d=d,mean_v=mean_v,sd_v=sd_v)$value,silent=T)
      if (is.numeric(tmp)) 
        outs[i] <- tmp else
        outs[i] <- 0
    }
    return(outs)
  }
}

{
# # Check
# n=1e5
# t0=.2; A=c(.5,.5); d=c(1.5,1.5); b=c(2,2); mean_v=c(2,1); sd_v=c(1,1)
# sim <- rlba.DK(n=n,A=A,b=b,d=d,mean_v=mean_v,sd_v=sd_v,t0=t0)
# sim$response[sim$response2==2] <- 0
# names(sim) <- c("RT","R","R2")
# sim$R <- factor(sim$R,labels=c("DK","r1","r2"))
# dns <- plot.cell.density(sim,xlim=c(0,5),save.density=TRUE)
# tapply(sim$RT,sim$R,mean)
# 
# # Sum to 1?
# integrate(n1PDFfixedt0.DK,lower=0,upper=Inf,A=A,b=b,d=d,mean_v=mean_v,sd_v=sd_v,r2="")$value+
# integrate(n1PDFfixedt0.DK,lower=0,upper=Inf,A=A[2:1],b=b[2:1],d=d[2:1],mean_v=mean_v[2:1],sd_v=sd_v[2:1],r2="")$value+
# integrate(n1PDFfixedt0.DK,lower=0,upper=Inf,A=A,b=b,d=d,mean_v=mean_v,sd_v=sd_v,r2="DK")$value
# 
# 
# # n1PDF check correct
# # red=black?
# d1 <- n1PDF.DK(dns$r1$x,r2="",A=A,b=b,d=d,mean_v=mean_v,sd_v=sd_v,t0=t0)
# d2 <- n1PDF.DK(dns$r2$x,r2="",A=A[2:1],b=b[2:1],d=d[2:1],mean_v=mean_v[2:1],sd_v=sd_v[2:1],t0=t0)
# dDK <- n1PDF.DK(dns$DK$x,r2="DK",A=A,b=b,d=d,mean_v=mean_v,sd_v=sd_v,t0=t0)
# plot(dns$r1$x,dns$r1$y,type="l",ylab="density",xlab="RT",lty=2,ylim=c(0,max(c(d1,d2,dDK))))
# lines(dns$r2$x,dns$r2$y,lty=3)
# lines(dns$DK$x,dns$DK$y,lty=1)
# lines(dns$r1$x,d1,col="red",lty=2)
# lines(dns$r2$x,d2,col="red",lty=3)
# lines(dns$DK$x,dDK,col="red",lty=1)
}

#####################  LBA with 2 level confidence response ----

rlba.2C <- function (n,A,b,d,t0,mean_v,sd_v,st0=0,posdrift=TRUE) 
  # response2: 1 = low confidence, 2 = high confidence
{
    if (any(b < A)) 
        stop("b cannot be smaller than A!")
    n_v  <- ifelse(is.null(dim(mean_v)), length(mean_v), dim(mean_v)[1])
    if ( posdrift ) 
        drifts <- matrix(rtnorm(n = n * n_v, mean = mean_v, sd = sd_v, 
            lower = 0), nrow = n_v)
    else drifts <- matrix(rnorm(n = n * n_v, mean = mean_v, sd = sd_v), 
        nrow = n_v)
    drifts[drifts < 0] <- 0
    starts <- matrix(runif(min = 0, max = A, n = n * n_v), nrow = n_v)
    ttf <- (b - starts)/drifts
    resp <- apply(ttf, 2, which.min)
    looser <- resp; looser[resp==1] <- 2; looser[resp==2] <- 1
    rt <- ttf[cbind(resp,1:n)] # actaully decision time, add t0 later
    
    # looser evidence = decison time * looser drift
    le <- rt*drifts[cbind(looser,1:n)]+starts[cbind(looser,1:n)]
    resp2 <- rep(2,length(resp))  # High confidence response
    resp2[le>d[looser]] <- 1      # Low confidence response response
    if ( !(st0[1]>0) ) rt <- rt + t0 else
      rt <- rt + t0 + runif(min = 0, max = st0[1], n = n)
    bad <- !is.finite(rt)
    if (any(bad)) {
        warning(paste(sum(bad), "infinite RTs removed and less than", 
            n, "rts returned"))
        resp <- resp[!bad]
        rt <- rt[!bad]
    }
    data.frame(rt = rt, response = resp, response2 = resp2)
}


# tmp <- rlba.2C(n=10,A=1,b=2,d=1,t0=.1,mean_v=c(1,0),sd_v=1,st0=0,posdrift=TRUE)
# 
# dt = c(.5,1,1.5,.5,1,1.5); r2 = c(rep("1",3),rep("2",3))
# d=A=c(1,1); b=d+1; mean_v=c(1,0); sd_v=c(1,1)

n1PDFfixedt0.2C <- function(dt,A,b,d,mean_v,sd_v, 
                           r2="2",posdrift=TRUE,robust = FALSE) 
# Generates defective PDF for responses on node= 1
# dt (decison time) is a matrix with length(mean_v) rows, one row for
# each accumulator to allow for different start times
{
  
  n_acc <- 2
  if (is.null(dim(dt))) dt <- matrix(rep(dt,each=n_acc),nrow=n_acc)
  if (!is.matrix(mean_v)) mean_v <- matrix(rep(mean_v,dim(dt)[2]),nrow=n_acc)
  if (!is.matrix(sd_v)) sd_v <- matrix(rep(sd_v,dim(dt)[2]),nrow=n_acc)
  if (!is.matrix(b)) b <- matrix(rep(b,dim(dt)[2]),nrow=n_acc)
  if (!is.matrix(d)) d <- matrix(rep(d,dim(dt)[2]),nrow=n_acc)
  if (!is.matrix(A)) A <- matrix(rep(A,dim(dt)[2]),nrow=n_acc)

  r2 <- rep(r2,length.out=dim(dt)[2])
  is.lo <- r2 =="1"
  
  if ( any(!is.lo) ) dt[1,!is.lo] <- 
    dlba.norm(dt[1,!is.lo],A=A[1,!is.lo],b=b[1,!is.lo],mean_v=mean_v[1,!is.lo],
      sd_v=sd_v[1,!is.lo],posdrift=posdrift,robust=robust)*
    (1-plba.norm(dt[2,!is.lo],A=A[2,!is.lo],b=d[2,!is.lo],
      mean_v=mean_v[2,!is.lo],sd_v=sd_v[2,!is.lo],posdrift=posdrift,robust=robust))
  if ( any(is.lo) ) dt[1,is.lo] <- 
    dlba.norm(dt[1,is.lo],A=A[1,is.lo],b=b[1,is.lo],
      mean_v=mean_v[1,is.lo],sd_v=sd_v[1,is.lo],posdrift=posdrift,robust=robust)*
      ((1-plba.norm(dt[2,is.lo],A=A[2,is.lo],b=b[2,is.lo],
        mean_v=mean_v[2,is.lo],sd_v=sd_v[2,is.lo],posdrift=posdrift,robust=robust))-
       (1-plba.norm(dt[2,is.lo],A=A[2,is.lo],b=d[2,is.lo],
        mean_v=mean_v[2,is.lo],sd_v=sd_v[2,is.lo],posdrift=posdrift,robust=robust)))
  dt[1,]
}


n1PDF.2C <- function (t,r2,A,b,d,mean_v,sd_v,t0,st0=0,posdrift=TRUE,robust = FALSE)
  # r2 is second respond, d is dont know crierion
{
  dt <- pmax(t-t0[1], 0)
  if (st0[1] == 0) 
    return(n1PDFfixedt0.2C(dt,r2=r2,A=A,b=b,d=d,mean_v=mean_v,sd_v=sd_v, 
                              posdrift=posdrift,robust = robust))
    else {
      tmpf <- function(tau,ti0,r2,A,b,d,mean_v,sd_v,scale,shape) 
        n1PDFfixedt0.2C(tau,r2,A,b,mean_v,sd_v)/st0
    outs <- numeric(length(dt))
    for (i in c(1:length(outs))) {
      tmp <- try(integrate(f=tmpf,
        lower=0,upper=dt[i],ti0=dt[i],r2=r2[i],
        A=A,b=b,d=d,mean_v=mean_v,sd_v=sd_v)$value,silent=T)
      if (is.numeric(tmp)) 
        outs[i] <- tmp else
        outs[i] <- 0
    }
    return(outs)
  }
}

{
# # Check
# n=1e5
# t0=.2; A=c(.5,.5); d=c(1.5,1); b=c(2,1.5); mean_v=c(2,1); sd_v=c(1,1)
# t0=.2; A=c(1,1); d=c(1.5,1.5); b=c(2.5,2.5); mean_v=c(2,1); sd_v=c(1,1)
# sim <- rlba.2C(n=n,A=A,b=b,d=d,mean_v=mean_v,sd_v=sd_v,t0=t0)
# names(sim) <- c("RT","R","R2")
# is.0 <- sim$R==1 & sim$R2==2
# is.3 <- sim$R==2 & sim$R2==2
# sim$R[is.0] <- 0
# sim$R[is.3] <- 3
# sim$R <- factor(sim$R,labels=c("hi1","lo1","lo2","hi2"))
# dns <- plot.cell.density(sim,xlim=c(0,5),save.density=TRUE)
# tapply(sim$RT,sim$R,mean)
# 
# # Sum to 1?
# integrate(n1PDFfixedt0.2C,lower=0,upper=Inf,A=A,b=b,d=d,mean_v=mean_v,sd_v=sd_v,r2="2")$value+
# integrate(n1PDFfixedt0.2C,lower=0,upper=Inf,A=A,b=b,d=d,mean_v=mean_v,sd_v=sd_v,r2="1")$value+
# integrate(n1PDFfixedt0.2C,lower=0,upper=Inf,A=A[2:1],b=b[2:1],d=d[2:1],mean_v=mean_v[2:1],sd_v=sd_v[2:1],r2="1")$value+
# integrate(n1PDFfixedt0.2C,lower=0,upper=Inf,A=A[2:1],b=b[2:1],d=d[2:1],mean_v=mean_v[2:1],sd_v=sd_v[2:1],r2="2")$value
# 
# # n1PDF check correct
# # red=black?
# d1lo <- n1PDF.2C(dns$lo1$x,r2="1",A=A,b=b,d=d,mean_v=mean_v,sd_v=sd_v,t0=t0)
# d2lo <- n1PDF.2C(dns$lo2$x,r2="1",A=A[2:1],b=b[2:1],d=d[2:1],mean_v=mean_v[2:1],sd_v=sd_v[2:1],t0=t0)
# d1hi <- n1PDF.2C(dns$hi1$x,r2="2",A=A,b=b,d=d,mean_v=mean_v,sd_v=sd_v,t0=t0)
# d2hi <- n1PDF.2C(dns$hi2$x,r2="2",A=A[2:1],b=b[2:1],d=d[2:1],mean_v=mean_v[2:1],sd_v=sd_v[2:1],t0=t0)
# plot(dns$hi1$x,dns$hi1$y,type="l",ylab="density",xlab="RT",lty=2,ylim=c(0,max(c(d1lo,d1hi,d2lo,d2hi))))
# lines(dns$hi1$x,d1hi,col="red",lty=2)
# lines(dns$lo1$x,dns$lo1$y,lty=3)
# lines(dns$lo1$x,d1lo,col="red",lty=3)
# lines(dns$lo2$x,dns$lo2$y,lty=1)
# lines(dns$lo2$x,d2lo,col="red",lty=1)
# lines(dns$hi2$x,dns$hi2$y,lty=4)
# lines(dns$hi2$x,d2hi,col="red",lty=4)
}

#####################  Gamma and Lognormal Non-decison time ## ----

# Used by these non-decison time models

n1PDFfixedt0.norm.old <- function(dt,A,b,mean_v,sd_v, 
                           posdrift=TRUE,robust = FALSE) 
# Generates defective PDF for responses on node= 1
# dt (decison time) is a vector with t0 removed
{
  out <- dlba.norm(t=dt,A=A[1],b=b[1],mean_v=mean_v[1],sd_v=sd_v[1],
                  posdrift=posdrift,robust=robust)
  if (length(mean_v)>1) for (i in 2:length(mean_v))
    out <- out*(1-plba.norm(t=dt,
      A=A[i],b=b[i],mean_v=mean_v[i],sd_v=sd_v[i],
      posdrift=posdrift,robust=robust))
  out
}

####################### LBA Gamma non-decision ----
{
rlba.norm.gamma <- function(n,A,b,t0,mean_v,sd_v,shape,scale,posdrift=TRUE) 
{
    if (any(b < A)) 
        stop("b cannot be smaller than A!")
    n_v <- length(mean_v)
    if (posdrift) 
      drifts <- matrix(rtnorm(n = n * n_v, mean = mean_v, sd = sd_v, 
                       lower = 0), nrow = n_v) else 
      drifts <- matrix(rnorm(n = n * n_v, mean = mean_v, sd = sd_v), nrow = n_v)
    out <- make.r(drifts=drifts,b=b,A=A,n_v=n_v,t0=t0,n = n)
    if (shape>0 & scale>0) 
      cbind.data.frame(RT=out$rt + rgamma(n,shape=shape[1],scale=scale[1]),
                       R=factor(out$response)) else
      cbind.data.frame(RT=out$rt,R=factor(out$response))
}


n1PDF.norm.gamma <- function (t,A,b,mean_v,sd_v,t0,shape,scale, 
                           posdrift=TRUE,robust = FALSE)
{
  dt <- pmax(t-t0[1], 0)
  if (shape[1] == 0 | scale[1] == 0) 
    return(n1PDFfixedt0.norm.old(dt=dt,A=A,b=b,mean_v=mean_v,sd_v=sd_v, 
                              posdrift=posdrift,robust = robust))
    else {
      tmpf <- function(tau,ti0,A,b,mean_v,sd_v,scale,shape) 
        n1PDFfixedt0.norm.old(tau,A,b,mean_v,sd_v)*
          dgamma(ti0-tau,shape=shape,scale=scale)
    outs <- numeric(length(dt))
    for (i in c(1:length(outs))) {
      tmp <- try(integrate(f=tmpf,
        lower=0,upper=dt[i],ti0=dt[i],
        A=A,b=b,mean_v=mean_v,sd_v=sd_v,
        scale=scale[1],shape=shape[1])$value,silent=T)
      if (is.numeric(tmp)) 
        outs[i] <- tmp else
        outs[i] <- 0
    }
    return(outs)
  }
}


# # Check
# n=1e6
# shape=0; scale=0
# shape=1; scale=1
# t0=.2; A=c(.5,.5); b=c(1,1); mean_v=c(1,.5); sd_v=c(1,1)
# sim <- rlba.norm.gamma(n=n,A=A,b=b,mean_v=mean_v,sd_v=sd_v,
#                        shape=shape,scale=scale,t0=t0)
# dns <- plot.cell.density(sim,C=1,xlim=c(0,7),save.density=TRUE)
# # n1PDF check corret
# d <- n1PDF.norm.gamma(dns$correct$x,A=A,b=b,mean_v=mean_v,sd_v=sd_v,t0=t0,
#                       shape=shape,scale=scale)
# # red=black?
# plot(dns$correct$x,dns$correct$y,type="l",ylab="density",xlab="RT")
# lines(dns$correct$x,d,col="red")
# # n1PDF check, error
# d <- n1PDF.norm.gamma(dns$error$x,A=A[2:1],b=b[2:1],
#                       mean_v=mean_v[2:1],sd_v=sd_v[2:1],t0=t0,
#                       shape=shape,scale=scale)
# lines(dns$error$x,dns$error$y,lty=2)
# lines(dns$error$x,d,col="red",lty=2)
}

####### LBA Gamma non-decision, MR linear angle effects (AS) on shape  ----
{
rlba.norm.gammaMR <- function(n,A,b,t0,mean_v,sd_v,shape,scale,AS,posdrift=TRUE) 
{
  shape <- shape*AS  
  if (any(b < A)) 
        stop("b cannot be smaller than A!")
    n_v <- length(mean_v)
    if (posdrift) 
      drifts <- matrix(rtnorm(n = n * n_v, mean = mean_v, sd = sd_v, 
                       lower = 0), nrow = n_v) else 
      drifts <- matrix(rnorm(n = n * n_v, mean = mean_v, sd = sd_v), nrow = n_v)
    out <- make.r(drifts=drifts,b=b,A=A,n_v=n_v,t0=t0,n = n)
    if (shape>0 & scale>0) 
      cbind.data.frame(RT=out$rt + rgamma(n,shape=shape[1],scale=scale[1]),
                       R=factor(out$response)) else
      cbind.data.frame(RT=out$rt,R=factor(out$response))
}


n1PDF.norm.gammaMR <- function (t,A,b,mean_v,sd_v,t0,shape,scale,AS, 
                           posdrift=TRUE,robust = FALSE)
{
  shape <- shape*AS  
  dt <- pmax(t-t0[1], 0)
  if (shape[1] == 0 | scale[1] == 0) 
    return(n1PDFfixedt0.norm.old(dt=dt,A=A,b=b,mean_v=mean_v,sd_v=sd_v, 
                              posdrift=posdrift,robust = robust))
    else {
      tmpf <- function(tau,ti0,A,b,mean_v,sd_v,scale,shape) 
        n1PDFfixedt0.norm.old(tau,A,b,mean_v,sd_v)*
          dgamma(ti0-tau,shape=shape,scale=scale)
    outs <- numeric(length(dt))
    for (i in c(1:length(outs))) {
      tmp <- try(integrate(f=tmpf,
        lower=0,upper=dt[i],ti0=dt[i],
        A=A,b=b,mean_v=mean_v,sd_v=sd_v,
        scale=scale[1],shape=shape[1])$value,silent=T)
      if (is.numeric(tmp)) 
        outs[i] <- tmp else
        outs[i] <- 0
    }
    return(outs)
  }
}


# # Check
# n=1e6
# shape=1; scale=1
# AS=0
# AS=1
# t0=.2; A=c(.5,.5); b=c(1,1); mean_v=c(1,.5); sd_v=c(1,1)
# sim <- rlba.norm.gammaMR(n=n,A=A,b=b,mean_v=mean_v,sd_v=sd_v,
#                        shape=shape,scale=scale,t0=t0,AS=AS)
# dns <- plot.cell.density(sim,C=1,xlim=c(0,7),save.density=TRUE)
# # n1PDF check corret
# d <- n1PDF.norm.gammaMR(dns$correct$x,A=A,b=b,mean_v=mean_v,sd_v=sd_v,t0=t0,
#                       shape=shape,scale=scale,AS=AS)
# # red=black?
# plot(dns$correct$x,dns$correct$y,type="l",ylab="density",xlab="RT")
# lines(dns$correct$x,d,col="red")
# # n1PDF check, error
# d <- n1PDF.norm.gammaMR(dns$error$x,A=A[2:1],b=b[2:1],
#                       mean_v=mean_v[2:1],sd_v=sd_v[2:1],t0=t0,
#                       shape=shape,scale=scale,AS=AS)
# lines(dns$error$x,dns$error$y,lty=2)
# lines(dns$error$x,d,col="red",lty=2)
}

####################### LBA Lognormal non-decision ----
{
rlba.norm.lnorm <- function(n,A,b,t0,mean_v,sd_v,meanlog,sdlog,posdrift=TRUE) 
{
    if (any(b < A)) 
        stop("b cannot be smaller than A!")
    n_v <- length(mean_v)
    if (posdrift) 
        drifts <- matrix(rtnorm(n = n * n_v, mean = mean_v, sd = sd_v, 
            lower = 0), nrow = n_v)
    else drifts <- matrix(rnorm(n = n * n_v, mean = mean_v, sd = sd_v), 
        nrow = n_v)
    out <- make.r(drifts=drifts,b=b,A=A,n_v=n_v,t0=t0,n = n)
    if (sdlog>0) 
      cbind.data.frame(RT=out$rt + rlnorm(n,meanlog=meanlog,sdlog=sdlog),
                       R=factor(out$response)) else
      cbind.data.frame(RT=out$rt,R=factor(out$response))
}

n1PDF.norm.lnorm <- function (t,A,b,mean_v,sd_v,t0,meanlog,sdlog, 
                           posdrift=TRUE,robust = FALSE)
{
  dt <- pmax(t-t0[1], 0)
  if (sdlog[1] == 0) 
    return(n1PDFfixedt0.norm.old(dt=dt,A=A,b=b,mean_v=mean_v,sd_v=sd_v, 
                              posdrift=posdrift,robust = robust))
    else {
      tmpf <- function(tau,ti0,A,b,mean_v,sd_v,meanlog,sdlog) 
        n1PDFfixedt0.norm.old(tau,A,b,mean_v,sd_v)*
          dlnorm(ti0-tau,meanlog=meanlog,sdlog=sdlog)
    outs <- numeric(length(dt))
    for (i in c(1:length(outs))) {
      tmp <- try(integrate(f=tmpf,
        lower=0,upper=dt[i],ti0=dt[i],
        A=A,b=b,mean_v=mean_v,sd_v=sd_v,
        meanlog=meanlog[1],sdlog=sdlog[1])$value,silent=T)
      if (is.numeric(tmp)) 
        outs[i] <- tmp else
        outs[i] <- 0
    }
    return(outs)
  }
}

# # Check
# n=1e6
# sdlog=1; meanlog=0
# t0=.2; A=c(.5,.5); b=c(1,1); mean_v=c(1,.5); sd_v=c(1,1)
# sim <- rlba.norm.lnorm(n=n,A=A,b=b,mean_v=mean_v,sd_v=sd_v,
#                        meanlog=meanlog,sdlog=sdlog,t0=t0)
# dns <- plot.cell.density(sim,C=1,xlim=c(0,7),save.density=TRUE)
# # n1PDF check, correct
# d <- n1PDF.norm.lnorm(dns$correct$x,A=A,b=b,mean_v=mean_v,sd_v=sd_v,t0=t0,
#                       meanlog=meanlog,sdlog=sdlog)
# # red=black?
# plot(dns$correct$x,dns$correct$y,type="l",ylab="density",xlab="RT")
# lines(dns$correct$x,d,col="red")
# # n1PDF check, error
# d <- n1PDF.norm.lnorm(dns$error$x,A=A[2:1],b=b[2:1],
#                       mean_v=mean_v[2:1],sd_v=sd_v[2:1],t0=t0,
#                       meanlog=meanlog,sdlog=sdlog)
# lines(dns$error$x,dns$error$y,lty=2)
# lines(dns$error$x,d,col="red",lty=2)
}

###############################################  ----
# IMPLEMENTED WITH ACCUMULATOR VECTORIZED t0
# LNR n-choice
# PNRWald (positive normal rate)
# Wald (uniform start point variability)
# LNR go-nogo
# LBA go-nogo
# LNR stop signal 
# ExGaussian stop signal.
# Wald stop signal
# LBA stop signal

####################### LNR n-choice ----
{
rlnr <- function (n, meanlog, sdlog, t0, st0 = 0) 
# Race among n_acc accumulators, mealnlog and sdlog can be n_acc length
# vectors or n_acc x n matrices. t0 can be
# a) a scalar, b) a vector of length number of accumulators or
# c) a matrix with 1 row per accumulator, when start times differ on each trial
# st0, range of non-decison time variability, must be a scalar, as the same
# variability is assumed in a common encoding/production stage

{
    n_acc <- ifelse(is.null(dim(meanlog)),length(meanlog),dim(meanlog)[1])
    dt <- matrix(rlnorm(n = n*n_acc, meanlog = meanlog, sdlog = sdlog), 
        nrow = n_acc) + t0
    winner <- apply(dt,2,which.min)    
    if (st0[1]==0) data.frame(RT=dt[cbind(winner,1:n)],R=winner) else
      data.frame(RT=dt[cbind(winner,1:n)]+runif(n,0,st0[1]),R=winner)
}

n1PDFfixedt0.lnr=function(dt,meanlog,sdlog) 
# Generates defective PDF for responses first among n_acc accumulator at 
# dt (decison time), a matrix with one row for each accumulator (allowing for
# different start times per accumulator) 
{
  
  n_acc <- ifelse(is.null(dim(meanlog)),length(meanlog),dim(meanlog)[1])
  if (!is.matrix(meanlog)) meanlog <- matrix(rep(meanlog,dim(dt)[2]),nrow=n_acc)
  if (!is.matrix(sdlog))     sdlog <- matrix(rep(  sdlog,dim(dt)[2]),nrow=n_acc)
  # winner
  dt[1,] <- dlnorm(dt[1,],meanlog[1,],sdlog[1,])
  # loosers
  if (dim(meanlog)[1]>1) for (i in 2:dim(meanlog)[1])
    dt[1,] <- dt[1,]*plnorm(dt[i,],meanlog[i,],sdlog[i,],lower.tail=FALSE)
  dt[1,]
}

n1PDF.lnr <- function(dt,meanlog,sdlog,t0,st0=0)
# dt (decision time) is a vector, meanlog and sdlog have same length = number of 
# accumulators, t0 is the lower bound of non-decision time, it can be:
# a) a scalar, b) a vector of length number of accumulators or
# c) a matrix with 1 row per accumulator, when start times differ on each trial
# st0, range of non-decison time variability, must be a scalar, as the same
# variability is assumed in a common encoding/production stage
{
  
  # NOTE: No need to flag negative dt in dt-t0 as plnorm/dlnorm return 0
             
  n_acc <- ifelse(is.null(dim(meanlog)),length(meanlog),dim(meanlog)[1])
  if (!is.matrix(meanlog)) meanlog <- matrix(rep(meanlog,length(dt)),nrow=n_acc)
  if (!is.matrix(sdlog))     sdlog <- matrix(rep(  sdlog,length(dt)),nrow=n_acc)
  if ( st0 < 1e-3 ) # smaller values can cause numerical integration problems
    return(n1PDFfixedt0.lnr(meanlog=meanlog,sdlog=sdlog,dt=matrix(
      pmax(rep(dt,each=n_acc)-t0,0),nrow=n_acc))) else
  {    
    
    integrate.f <- function(dt,meanlog,sdlog,t0,st0) 
      n1PDFfixedt0.lnr(meanlog=meanlog,sdlog=sdlog,dt=matrix(
        pmax(rep(dt,each=length(meanlog))-t0,0),nrow=length(meanlog)))/st0
    
    outs <- numeric(length(dt))
    for (i in 1:length(outs)) {
      tmp <- try(integrate(f=integrate.f,
        lower=dt[i]-st0[1],upper=dt[i],
        meanlog=meanlog[,i],sdlog=sdlog[,i],t0=t0,st0=st0[1])$value,silent=TRUE)
      if (is.numeric(tmp)) 
        outs[i] <- tmp else
        outs[i] <- 0
    }
    return(outs)
  }
}


# # Check
# n=1e5
# meanlog=c(.5,.75,1); sdlog=c(1,1,1)
# n_acc <- length(meanlog)
# 
# # check scalar t0
# t0=.2
# t0=c(.2,1,1)
# 
# # check t0 noise
# st0=1
# st0=0
# 
# sim <- rlnr(n=n,meanlog,sdlog,t0,st0)
# dns <- plot.cell.density(sim,xlim=c(0,7),save.density=TRUE)
# 
# # Check matrix forms work
# meanlog <- matrix(rep(meanlog,length(dns[[ichar]]$x)),nrow=n_acc)
# sdlog <- matrix(rep(sdlog,length(dns[[ichar]]$x)),nrow=n_acc)
# t0 <- matrix(rep(t0,length.out=n_acc*length(dns[[ichar]]$x)),nrow=n_acc)
# 
# check_n1 <- TRUE   # n1PDF check
# check_n1 <- FALSE  # n1PDFfixedt0.lnr check (ignores st0)
# 
# for (i in 1:n_acc) {
#   ichar <- as.character(i)
#   indx <- c(i,c(1:n_acc)[-i])
#   if (!is.matrix(meanlog)) meanlogi <- meanlog[indx] else meanlogi <- meanlog[indx,]
#   if (!is.matrix(sdlog))     sdlogi <- sdlog[indx] else     sdlogi <- sdlog[indx,]
#   if (!is.matrix(t0)) {
#     if (length(t0)!=1) t0i <- t0[indx] else t0i <- t0 
#   } else t0i <- t0[indx,]
#   if (check_n1) d <- n1PDF.lnr(dt=dns[[ichar]]$x,meanlogi,sdlogi,t0i,st0=st0) else
#     d <- n1PDFfixedt0.lnr(meanlog=meanlogi,sdlog=sdlogi,
#       dt=matrix(pmax(rep(dns[[ichar]]$x,each=n_acc)-t0i,0),nrow=n_acc))
#   if (i!=1) lines(dns[[ichar]]$x,dns[[ichar]]$y,lty=i) else
#     plot(dns[[ichar]]$x,dns[[ichar]]$y,type="l",xlab="RT",ylab="Density") 
#   lines(dns[[ichar]]$x,d,col="red",lty=i)
# }
}

######################## PNRWald ----

# n-choice postivie (zero truncated) normal rate trial to trial ~N(v,sv) Wald 
#    race, with t0, v, sv, a (boundary) parameterixaiton

# require("statmod") invgauss random, pdf, cdf etc.
# This has parameterizaiton mean (expected value) and dispersion = 1/shape. In 
# the accumulator interpritaiton dispersion is scaled relative to threshold (a)
# so without loss of generality we can set diffusion coefficeint to 1 and so
# shape = a^2. Using the notation v = mean rate, expected value (mean) = a/v 
# and varaince = mean^3 / a^2 = a / v^3

### Single accumulator model

rPNRWald <- function(n,a,v,sv,t0)
  # random function for single acumulator
{
    drifts <- matrix(rtnorm(n = n , mean = v, sd = sv, lower = 0), 
                     nrow = length(v))
    t0+rinvgauss(n,mean=a/drifts,shape=a^2)        
}


dPNRWald <- function(t,a,v,sv,posdrift=TRUE)
  # density for single accumulator
{
  # Convert to Desmond and Yang's notation
  d <- v/a # mean of delta
  l <- a^2 # lambda assuming diffusive variance is 1
  v <- sv^2 # variance of delta
  sqrt(l/(2*pi*t^3*(v*t+1)))*exp(-(l*(d*t-1)^2)/(2*t*(v*t+1)))*
  pnorm((v+d)*sqrt(l/(t*v^2+v)))/pnorm(d*sqrt(l/v)) # normalize
}


# # Check density and normalization
# n=1e6; a=3; v=2; sv=1
# integrate(dPNRWald,lower=0,upper=Inf,a=a,v=v,sv=sv)
# sim <- rPNRWald(n=n,a=a,v=v,sv=sv,t0=0)
# bad <- sim>10; mean(bad) # if this is large the check isnt valid
# dns <- density(sim[!bad])
# x <- dns$x[dns$x>0]
# d <- dPNRWald(x,a=a,v=v,sv=sv)
# plot(dns)
# lines(x,d,col="red")


pPNRWald <- function(t,a,v,sv)
  # cumulative density for single accumulator, NB: direct integration of
  # dPNRWald fails! This method using the analytic for the un-mixed
  # Wald CDF works much better
{
  if ( length(c(a,v,sv))>3 )
    stop("pPNRWald can only handle scalar parameters")
  ifun <- function(x,a,v,sv,t) {
    out <- dtnorm(x,v,sv,lower=0)*pinvgauss(t,mean=a/x,shape=a^2)
    ifelse(is.finite(out),out,0) 
  }
  
#   for (i in 1:length(t)) {
#     int <- try(integrate(ifun,lower=0,upper=Inf,a=a,v=v,sv=sv,t=t[i]),silent=TRUE)
#     if (class(int)=="try-error") t[i] <- 0 else t[i] <- int$value
#   }     

  uniquet <- unique(t) # scrimp some speed by calculating only for unqiue
  for (i in 1:length(uniquet)) {
    int <- try(integrate(ifun,lower=0,upper=Inf,a=a,v=v,sv=sv,t=uniquet[i]),silent=TRUE)
    if (class(int)=="try-error") 
      t[t==uniquet[i]] <- 0 else t[t==uniquet[i]] <- int$value
  }     

  t[t<0] <- 0; t[t>1] <- 1 
  t
}


# # Check cumulative density
# n=1e6; a=.1; v=.2; sv=1
# sim <- rPNRWald(n=n,a=a,v=v,sv=sv,t0=0)
# probs=1:990/1000
# qs <- quantile(sim,probs=probs)
# cd <- pPNRWald(qs,a=a,v=v,sv=sv)
# plot(qs,probs,type="l")
# lines(qs,cd,col="red")
# 
# # Speed up by using unique t
# sim <- rPNRWald(n=1e4,a=a,v=v,sv=sv,t0=0)
# system.time(pPNRWald(sim,a=a,v=v,sv=sv))
# #    user  system elapsed 
# #   7.720   0.009   7.731
# sim <- round(sim*1000)/1000
# system.time(pPNRWald(sim,a=a,v=v,sv=sv))
# #    user  system elapsed 
# #   0.875   0.000   0.875 
  
### Race model

rPNRWaldRace <- function(n,a,v,sv,t0,gf=0) 
  # random function for PNRWald race, if all accumualtors have non-poistive 
  # rates race deleted and warning returned. If only one has positve rate and sv
  # then do single accumulator special case, so can be accessed by setting v=0
  # and sv=0 for all other accumulators.
{
  n_v <- length(v)
  single_v <- c(1:length(v))[v>0] # Single accumulator case 
  if ( (length(single_v)==1) && 
      ( ( (length(sv)==1) && (sv<=0) ) || (all(sv[-single_v]<=0)) ) ) { 
      out <- data.frame(RT=rPNRWald(n,a[single_v],v[single_v],sv[single_v],t0[1]),
                        R=factor(rep(single_v,n),levels=1:n_v))  
    } else {
      drifts <- matrix(rtnorm(n=n*n_v,mean=v,sd=sv,lower=0),nrow=n_v) 
      ttf <- matrix(t0 + rinvgauss(n*n_v,mean=a/drifts,shape=a^2),nrow=n_v)
      resp <- apply(ttf, 2, which.min)
      out <- data.frame(RT = ttf[cbind(resp,1:n)], 
                        R = factor(apply(ttf, 2, which.min),levels=1:n_v))
    }
    if (gf[1] > 0) {
      is.gf <- as.logical(rbinom(dim(out)[1],1,gf))
      out$RT[is.gf] <- NA
      out$R[is.gf] <- 1
    }

    out

}


n1PNRWald <- function(dt,a,v,sv,t0,gf=0,posdrift=TRUE)
# Generates defective PDF for responses on node=1dt (decison time) is a vector of times
# If only one has positve rate and sv then do single accumulator special case, 
# so can be accessed by setting v=0 and sv=0 for all other accumulators.
{
  # Some protection for negative dt values, remove if not needed
  dt <- dt-t0
  good <- is.go <- !is.na(dt)
  good[good] <- dt[good] > 0
  
  d <- numeric(length(dt))
  d[good] <- (1-gf[1])*dPNRWald(dt[good],a=a[1],v=v[1],sv=sv[1])
  single_v <- c(1:length(v))[v>0] 
  if ( !( (length(single_v)==1) && 
      ( ( (length(sv)==1) && (sv<=0) ) || (all(sv[-single_v]<=0)) )) )
      for (i in 2:length(v))
        d[good] <- d[good]*(1-pPNRWald(dt[good],a=a[i],v=v[i],sv=sv[i]))
  
  d[!is.go] <- gf[1]
  
  d
}


# # Check 
# n=1e5
# v=c(4,0.5); sv=c(1,1); a=c(2,2); t0=0.5
# sim <- rPNRWaldRace(n=n,a=a,v=v,sv=sv,t0=t0)
# 
# par(mfrow=c(1,2))
# dns <- plot.cell.density(sim,C=1,xlim=c(0,4),save.density=TRUE)
# # NB: Direclty integrating again appears very inaccurate
# integrate(n1PNRWald,lower=t0,upper=Inf,a=a,v=v,sv=sv,t0=t0)$value
# dt=dns$correct$x
# d <- n1PNRWald(dt,a=a,v=v,sv=sv,t0=t0)
# # red=black?
# plot(dns$correct$x,dns$correct$y,type="l")
# lines(dns$correct$x,d,col="red")
# 
# # With go failure
# n=1e5
# v=c(2,0.5); sv=c(1,1); a=c(2,2); t0=0.5; gf=.2
# sim <- rPNRWaldRace(n=n,a=a,v=v,sv=sv,t0=t0,gf=gf)
# par(mfrow=c(1,3))
# dns <- plot.cell.density(sim,C=1,xlim=c(0,4),save.density=TRUE)
# # NB: Direclty integrating again appears very inaccurate
# integrate(n1PNRWald,lower=t0,upper=Inf,a=a,v=v,sv=sv,t0=t0,gf=gf)$value/(1-gf)
# dt=dns$correct$x
# d <- n1PNRWald(dt,a=a,v=v,sv=sv,t0=t0,gf=gf)
# # red=black?
# plot(dns$correct$x,dns$correct$y,type="l")
# lines(dns$correct$x,d,col="red")
# dt=dns$error$x
# d <- n1PNRWald(dt,a=a[2:1],v=v[2:1],sv=sv[2:1],t0=t0,gf=gf)
# # red=black?
# plot(dns$error$x,dns$error$y,type="l")
# lines(dns$error$x,d,col="red")

# # Single accumlator with go failure
# n=1e5
# v=c(3,0); sv=c(1,0); a=c(2,2); t0=0.5; gf=.2
# sim <- rPNRWaldRace(n=n,a=a,v=v,sv=sv,t0=t0,gf=gf)
# par(mfrow=c(1,3))
# dns <- plot.cell.density(sim,C=1,xlim=c(0,4),save.density=TRUE)
# # NB: Direclty integrating again appears very inaccurate
# integrate(n1PNRWald,lower=t0,upper=Inf,a=a,v=v,sv=sv,t0=t0,gf=gf)$value/(1-gf)
# dt=dns$correct$x
# d <- n1PNRWald(dt,a=a,v=v,sv=sv,t0=t0,gf=gf)
# # red=black?
# plot(dns$correct$x,dns$correct$y,type="l")
# lines(dns$correct$x,d,col="red")
# 
# n=1e5
# v=c(0,3); sv=c(0,1); a=c(2,2); t0=0.5; gf=.2
# sim <- rPNRWaldRace(n=n,a=a,v=v,sv=sv,t0=t0,gf=gf)
# par(mfrow=c(1,3))
# dns <- plot.cell.density(sim,C=1,xlim=c(0,4),save.density=TRUE)
# # NB: Direclty integrating again appears very inaccurate
# 1-integrate(n1PNRWald,lower=t0,upper=Inf,a=a[2:1],v=v[2:1],sv=sv[2:1],t0=t0,gf=gf)$value/(1-gf)
# dt=dns$error$x
# d <- n1PNRWald(dt,a=a[2:1],v=v[2:1],sv=sv[2:1],t0=t0,gf=gf)
# # red=black?
# plot(dns$error$x,dns$error$y,type="l")
# lines(dns$error$x,d,col="red")

######################## Wald ----

# n-choice uniformly varying start point (0-A) Wald 
#    race, with t0, v, A, b (boundary) parameterixaiton

### Single accumulator model

# pigt, digt, rwaldt Copyright (C) 2013  Trisha Van Zandt distributed with: 
# Logan, Van Zandt, Verbruggen, and Wagenmakers (2014).  On the ability to 
# inhibit thought and action: General and special theories of an act of control.
# Psychological Review. Comments and changes added by Andrew Heathcote. Trish's
# code is for k = threshold, a = half width of uniform threshold variability,
# l = rate of accumulation. Note that Wald mean = k/l and shape = k^2.

# Following functions use a different parameterization in terms of v=l (rate),
# uniform start point variability from 0-A (A>=0), threshold b (>0) and hence 
# B=b-A (>=0) as a threshold gap. Hence k = b-A/2 = B + A/2 and a=A 

rWald <- function(n,B,v,A)
  # random function for single acumulator
{
  
  rwaldt <- function(n,k,l,tiny=1e-6) {
  # random sample of n from a Wald (or Inverse Gaussian)
  # k = criterion, l = rate, assumes sigma=1 Browninan motion
  # about same speed as statmod rinvgauss
  
    rlevy <- function(n=1, m=0, c=1) {
      if (any(c<0)) stop("c must be positive")
      c/qnorm(1-runif(n)/2)^2+m
    }
    
    flag <- l>tiny
    x <- rep(NA,times=n)
    
    x[!flag] <- rlevy(sum(!flag),0,k[!flag]^2)
    mu <- k/l
    lambda <- k^2
    
    y <- rnorm(sum(flag))^2
    mu.0 <- mu[flag]
    lambda.0 <- lambda[flag]
    
    x.0 <- mu.0 + mu.0^2*y/(2*lambda.0) -
      sqrt(4*mu.0*lambda.0*y + mu.0^2*y^2)*mu.0/(2*lambda.0)
    
    z <- runif(length(x.0))
    test <- mu.0/(mu.0+x.0)
    x.0[z>test] <- mu.0[z>test]^2/x.0[z>test]
    x[flag] <- x.0
    x[x<0] <- max(x)
    x
  }

  # Act as if negative v never terminates, cluge to do single accumulator
  # case by passing negative v
  if (length(v)!=n) v <- rep(v,length.out=n)
  if (length(B)!=n) B <- rep(B,length.out=n)
  if (length(A)!=n) A <- rep(A,length.out=n)
  
  # Kluge to return -Inf for negative rates, so can implment one accumulator case
  out <- numeric(n)
  ok <- v>0  
  nok <- sum(ok)
  bs <- B[ok]+runif(nok,0,A[ok])
  out[ok] <- rwaldt(nok,k=bs,l=v[ok])
  out[!ok] <- Inf
  out
}


dWald <- function(t,v,B,A)
  # density for single accumulator
{

  digt <- function(t,k=1,l=1,a=.1,tiny=1e-10) {
  # pdf of inverse gaussian at t with k +/- a/2 uniform variability
  # returns digt.0 if a<1e-10 
    
    digt.0 <- function(t,k=1,l=1) {
      # pdf of inverse gaussian at t with no k variability
      # much faster than statmod's dinvgauss funciton

      lambda <- k^2
      l0 <- l==0
      e <- numeric(length(t))
      if ( any(!l0) ) {
        mu <- k[!l0]/l[!l0]
        e[!l0] <- -(lambda[!l0]/(2*t[!l0])) * (t[!l0]^2/mu^2 - 2*t[!l0]/mu  + 1)
      }
      if ( any(l0) )  e[l0] <- -.5*lambda[l0]/t[l0]
      x <- exp(e + .5*log(lambda) - .5*log(2*t^3*pi))
      x[t<=0] <- 0
      x
    }
    
    options(warn=-1)
    if(length(k)!=length(t)) k <- rep(k,length.out=length(t))
    if(length(l)!=length(t)) l <- rep(l,length.out=length(t))
    if(length(a)!=length(t)) a <- rep(a,length.out=length(t))

    tpos <- t<=0
  
    atiny <- a<=tiny & !tpos
    a[atiny] <- 0

    ltiny <- (l<=tiny) & !atiny & !tpos
    notltiny <- (l>tiny) & !atiny & !tpos
    l[l<=tiny] <- 0
   
    x <- numeric(length(t))
  
    # No threshold variability
    if ( any(atiny) )
      x[atiny] <- digt.0(t=t[atiny],k=k[atiny],l=l[atiny])
 
    # Threshold variability
    if ( any(!atiny) ) {
    
      if ( any(notltiny) ) { # rate non-zero
      
        sqr.t <- sqrt(t[notltiny])

        term.1a <- -(a[notltiny]-k[notltiny]+t[notltiny]*l[notltiny])^2/(2*t[notltiny])
        term.1b <- -(a[notltiny]+k[notltiny]-t[notltiny]*l[notltiny])^2/(2*t[notltiny])
        term.1 <- (exp(term.1a) - exp(term.1b))/sqrt(2*pi*t[notltiny])

        term.2a <- log(.5)+log(l[notltiny])
        term.2b <- 2*pnorm((-k[notltiny]+a[notltiny])/sqr.t+sqr.t*l[notltiny])-1
        term.2c <- 2*pnorm((k[notltiny]+a[notltiny])/sqr.t-sqr.t*l[notltiny])-1
        term.2d <- term.2b+term.2c
        term.2 <- exp(term.2a)*term.2d
      
        term.3 <- term.1+term.2
        term.4 <- log(term.3)-log(2)-log(a[notltiny])
        x[notltiny] <- exp(term.4)
      }
    
      if ( any(ltiny) ) {  # rate zero
        log.t <- log(t[ltiny])
        term.1 <- -.5*(log(2)+log(pi)+log.t)
        term.2 <- (k[ltiny]-a[ltiny])^2/(2*t[ltiny])
        term.3 <- (k[ltiny]+a[ltiny])^2/(2*t[ltiny])
        term.4 <- (exp(-term.2)-exp(-term.3))
        term.5 <- term.1+log(term.4) - log(2) - log(a[ltiny])
        x[ltiny] <- exp(term.5)
      }
  
    }
  
    x[x<0 | is.nan(x) ] <- 0
    x
  }

  out <- numeric(length(t))
  ok <- v>0
  out[ok] <- digt(t[ok],k=B[ok]+A[ok]/2,l=v[ok],a=A[ok]/2)
  out[!ok] <- 0
  out
}


# Check density and normalization
# par(mfrow=c(1,2))
# n=1e6; A=0; v=2; B=1
# integrate(dWald,lower=0,upper=Inf,A=A,v=v,B=B)
# sim <- rWald(n=n,A=A,v=v,B=B)
# bad <- sim>10; mean(bad) # if this is large the check isnt valid
# dns <- density(sim[!bad])
# x <- dns$x[dns$x>0]
# d <- dWald(x,A=A,v=v,B=B)
# plot(dns)
# lines(x,d,col="red")
# 
# n=1e6; A=1; v=2; B=1
# integrate(dWald,lower=0,upper=Inf,A=A,v=v,B=B)
# sim <- rWald(n=n,A=A,v=v,B=B)
# bad <- sim>10; mean(bad) # if this is large the check isnt valid
# dns <- density(sim[!bad])
# x <- dns$x[dns$x>0]
# d <- dWald(x,A=A,v=v,B=B)
# plot(dns)
# lines(x,d,col="red")


pWald <- function(t,v,B,A)
  # cumulative density for single accumulator
{
  pigt <- function(t,k=1,l=1,a=.1,tiny=1e-10) {
    # cdf of inverse gaussian at t with k +/- a/2 uniform variability
    # returns pigt.0 if a<=0
    
    pigt.0 <- function(t,k=1,l=1) {
      # cdf of inverse gaussian at t with no k variability
      # much faster than statmod's pinvgauss funciton
   
      mu <- k/l
      lambda <- k^2
        
      e <- exp(log(2*lambda) - log(mu))
      add <- sqrt(lambda/t) * (1 + t/mu)
      sub <- sqrt(lambda/t) * (1 - t/mu)
       
      p.1 <- 1 - pnorm(add)
      p.2 <- 1 - pnorm(sub)
      x <- exp(e + log(p.1)) + p.2
       
      x[t<0] <- 0
      x
   }
    
   options(warn=-1)
   if(length(k)!=length(t)) k <- rep(k,length.out=length(t))
   if(length(l)!=length(t)) l <- rep(l,length.out=length(t))
   if(length(a)!=length(t)) a <- rep(a,length.out=length(t))

   tpos <- t<=0

   atiny <- a<=tiny & !tpos
   a[atiny] <- 0

   ltiny <- (l<=tiny) & !atiny & !tpos
   notltiny <- (l>tiny) & !atiny & !tpos
   l[l<=tiny] <- 0
   
   x <- numeric(length(t))
    
   # No threshold variability
   if ( any(atiny) )
     x[atiny] <- pigt.0(t[atiny],k[atiny],l[atiny])
   
   # Threshold variability
   if ( any(!atiny) ) {
    
     if ( any(notltiny) ) { # rate non-zero
      
       log.t <- log(t[notltiny])
       sqr.t <- sqrt(t[notltiny])

       term.1a <- .5*log.t-.5*log(2*pi)
       term.1b <- exp(-((k[notltiny]-a[notltiny]-t[notltiny]*l[notltiny])^2/t[notltiny])/2)
       term.1c <- exp(-((k[notltiny]+a[notltiny]-t[notltiny]*l[notltiny])^2/t[notltiny])/2)
       term.1 <- exp(term.1a)*(term.1b-term.1c)
     
       term.2a <- exp(2*l[notltiny]*(k[notltiny]-a[notltiny]) + 
           log(pnorm(-(k[notltiny]-a[notltiny]+t[notltiny]*l[notltiny])/sqr.t)))
       term.2b <- exp(2*l[notltiny]*(k[notltiny]+a[notltiny]) + 
           log(pnorm(-(k[notltiny]+a[notltiny]+t[notltiny]*l[notltiny])/sqr.t)))
       term.2 <- a[notltiny] + (term.2b-term.2a)/(2*l[notltiny])
     
       term.4a <- 2*pnorm((k[notltiny]+a[notltiny])/sqr.t-sqr.t*l[notltiny])-1
       term.4b <- 2*pnorm((k[notltiny]-a[notltiny])/sqr.t-sqr.t*l[notltiny])-1
       term.4c <- .5*(t[notltiny]*l[notltiny] - a[notltiny] - k[notltiny] + .5/l[notltiny])
       term.4d <- .5*(k[notltiny] - a[notltiny] - t[notltiny]*l[notltiny] - .5/l[notltiny])
       term.4 <- term.4c*term.4a + term.4d*term.4b
    
       x[notltiny] <- (term.4 + term.2 + term.1)/(2*a[notltiny])
     }
    
     if ( any(ltiny) ) {  # rate zero
       sqr.t <- sqrt(t[ltiny])
       log.t <- log(t[ltiny])
       term.5a <- 2*pnorm((k[ltiny]+a[ltiny])/sqr.t)-1
       term.5b <- 2*pnorm(-(k[ltiny]-a[ltiny])/sqr.t)-1
       term.5 <- (-(k[ltiny]+a[ltiny])*term.5a - (k[ltiny]-a[ltiny])*term.5b)/(2*a[ltiny])
       
       term.6a <- -.5*(k[ltiny]+a[ltiny])^2/t[ltiny] - .5*log(2) -.5*log(pi) + .5*log.t - log(a[ltiny])
       term.6b <- -.5*(k[ltiny]-a[ltiny])^2/t[ltiny] - .5*log(2) -.5*log(pi) + .5*log.t - log(a[ltiny])
       term.6 <- 1 + exp(term.6b) - exp(term.6a)
     
       x[ltiny] <- term.5 + term.6
     }
    
    }
  
    x[x<0 | is.nan(x) ] <- 0
    x
  }

  out <- numeric(length(t))
  ok <- v>0
  out[ok] <- pigt(t[ok],k=B[ok]+A[ok]/2,l=v[ok],a=A[ok]/2)
  out[!ok] <- 0
  out

}


# # Check cumulative density
# par(mfrow=c(1,2))
# 
# n=1e6; A=0; v=2; B=1
# sim <- rWald(n=n,A=A,v=v,B=B)
# probs=1:990/1000
# qs <- quantile(sim,probs=probs)
# cd <- pWald(qs,A=A,v=v,B=B)
# plot(qs,probs,type="l")
# lines(qs,cd,col="red")
# 
# n=1e6; A=1; v=2; B=1
# sim <- rWald(n=n,A=A,v=v,B=B)
# probs=1:990/1000
# qs <- quantile(sim,probs=probs)
# cd <- pWald(qs,A=A,v=v,B=B)
# plot(qs,probs,type="l")
# lines(qs,cd,col="red")

### Race model

rWaldRace <- function(n,v,B,A,t0,gf=0,return.ttf=FALSE) 
  # random function for Wald race.
{
    B[B<0] <- 0 # Protection for negatives 
    A[A<0] <- 0
    n_v  <- ifelse(is.null(dim(v)), length(v), dim(v)[1])
    ttf <- matrix(t0 + rWald(n*n_v,B=B,v=v,A=A),nrow=n_v)
    if (return.ttf) return(ttf)
    resp <- apply(ttf, 2, which.min)
    out <- data.frame(RT = ttf[cbind(resp,1:n)], R = apply(ttf, 2, which.min))
    
    if (gf[1] > 0) {
      is.gf <- as.logical(rbinom(dim(out)[1],1,gf))
      out$RT[is.gf] <- NA
      out$R[is.gf] <- 1
    }

    out
}


n1Wald <- function(dt,v,B,A,t0,gf=0)
# Generates defective PDF for responses on node=1, dt (decison time) is a vector of times
{
  B[B<0] <- 0 # Protection for negatives 
  A[A<0] <- 0
  n_acc <- ifelse(is.null(dim(v)),length(v),dim(v)[1])
  if (is.null(dim(dt))) dt <- matrix(rep(dt,each=n_acc),nrow=n_acc)
  dt <- dt-t0
  
  is.go <- !is.na(dt[1,])
  n.go <- sum(is.go)
  
  if (!is.matrix(v)) v <- matrix(rep(v,n.go),nrow=n_acc)
  if (!is.matrix(B)) B <- matrix(rep(B,n.go),nrow=n_acc)
  if (!is.matrix(A)) A <- matrix(rep(A,n.go),nrow=n_acc)

  # Winner
  dt[1,is.go] <- (1-gf[1])*dWald(dt[1,is.go],A=A[1,],v=v[1,],B=B[1,])
  if (n_acc > 1) for (i in 2:n_acc)
    dt[1,is.go] <- dt[1,is.go]*(1-pWald(dt[i,is.go],A=A[i,],v=v[i,],B=B[i,]))
  
  dt[1,!is.go] <- gf[1]
  
  dt[1,]
}


# # Check no go failure 
# n=1e5
# v=c(2,1); B=c(1,1); A=c(2,2); t0=1
# sim <- rWaldRace(n=n,A=A,v=v,B=B,t0=t0)
# par(mfrow=c(1,3))
# dns <- plot.cell.density(sim,C=1,xlim=c(0,4),save.density=TRUE)
# pc <- integrate(n1Wald,lower=0,upper=Inf,A=A,v=v,B=B,t0=t0)$value
# print(pc)
# dt=dns$correct$x
# d <- n1Wald(dt,A=A,v=v,B=B,t0=t0)
# # red=black?
# plot(dns$correct$x,dns$correct$y,type="l")
# lines(dns$correct$x,d,col="red")
# dt=dns$error$x
# d <- n1Wald(dt,A=A[2:1],v=v[2:1],B=B[2:1],t0=t0)
# plot(dns$error$x,dns$error$y,lty=2,type="l")
# lines(dns$error$x,d,col="red",lty=2)
# 
# # Check go failure 
# n=1e5
# v=c(2,1); B=c(1,1); A=c(2,2); t0=1; gf=.2
# sim <- rWaldRace(n=n,A=A,v=v,B=B,t0=t0,gf=gf)
# par(mfrow=c(1,3))
# dns <- plot.cell.density(sim,C=1,xlim=c(0,4),save.density=TRUE)
# pc <- integrate(n1Wald,lower=0,upper=Inf,A=A,v=v,B=B,t0=t0)$value
# print(pc)
# dt=dns$correct$x
# d <- n1Wald(dt,A=A,v=v,B=B,gf=gf,t0=t0)
# # red=black?
# plot(dns$correct$x,dns$correct$y,type="l")
# lines(dns$correct$x,d,col="red")
# dt=dns$error$x
# d <- n1Wald(dt,A=A[2:1],v=v[2:1],B=B[2:1],gf=gf,t0=t0)
# plot(dns$error$x,dns$error$y,lty=2,type="l")
# lines(dns$error$x,d,col="red",lty=2)

# # Check (effectively) single accumulator case 
# n=1e5
# v=c(2,-1); B=c(1,1); A=c(2,2); t0=1
# sim <- rWaldRace(n=n,A=A,v=v,B=B,t0=t0)
# par(mfrow=c(1,4))
# dns <- plot.cell.density(sim,C=1,xlim=c(0,4),save.density=TRUE)
# pc <- integrate(n1Wald,lower=0,upper=Inf,A=A,v=v,B=B,t0=t0)$value
# print(pc)
# dt=dns$correct$x
# d <- n1Wald(dt,A=A,v=v,B=B,t0=t0)
# # red=black?
# plot(dns$correct$x,dns$correct$y,type="l")
# lines(dns$correct$x,d,col="red")
# 
# v=c(-1,2); B=c(1,1); A=c(2,2); t0=1
# sim <- rWaldRace(n=n,A=A,v=v,B=B,t0=t0)
# dns <- plot.cell.density(sim,C=1,xlim=c(0,4),save.density=TRUE)
# pe <- integrate(n1Wald,lower=0,upper=Inf,A=A,v=v,B=B,t0=t0)$value
# print(pe)
# dt=dns$error$x
# d <- n1Wald(dt,A=A[2:1],v=v[2:1],B=B[2:1],gf=gf,t0=t0)
# # red=black?
# plot(dns$error$x,dns$error$y,type="l")
# lines(dns$error$x,d,col="red")

####################### LNR go-nogo ----
{
rlnrgng <- function (n, meanlog, sdlog, t0, st0 = 0) 
# Race among length(meanlog) accumulators, first of which is a no-go 
# accumulator. For trials with winning first accumulator RT set to NA.   
{
   out <- rlnr(n,meanlog,sdlog,t0,st0)
   out[out$R==1,"RT"] <- NA
   out$R <- factor(as.numeric(out$R))
   data.frame(out)
}
 

n1PDFfixedt0.lnrgng=function(dt,meanlog,sdlog) 
# Same as n1PDFfixedt0.lnr except dt=NA done by integration
{
  
  stopfn <- function(t,meanlog,sdlog) 
  {
    n1PDFfixedt0.lnr(
      matrix(rep(t,each=length(meanlog)),nrow=length(meanlog)),
      meanlog,sdlog
    )
  }
  
  n.trials <- dim(dt)[2]
  out <- numeric(n.trials)
  is.stop <- is.na(dt[1,])
  dt[1,!is.stop] <- n1PDFfixedt0.lnr(dt[,!is.stop,drop=F],meanlog,sdlog)
  # tmp <- try(integrate(f=stopfn,lower=0,upper=Inf,
  #     meanlog=meanlog,sdlog=sdlog)$value,silent=TRUE)
  # if (!is.numeric(tmp)) tmp <- 0
  tmp <- my.integrate(f=stopfn,lower=0,meanlog=meanlog,sdlog=sdlog)
  dt[1,is.na(dt[1,])] <- tmp 
  dt[1,]
}

n1PDF.lnrgng <- function(dt,meanlog,sdlog,t0,st0=0)
# Same as n1PDF.lnr except NAs dealt with by integration
{
    
  if ( st0 < 1e-3 ) # smaller values can cause numerical integration problems
    return(n1PDFfixedt0.lnrgng(meanlog=meanlog,sdlog=sdlog,dt=matrix(
      pmax(rep(dt,each=length(meanlog))-t0,0),nrow=length(meanlog)))
    ) else
  {    
    
    integrate.f <- function(dt,meanlog,sdlog,t0,st0) 
      n1PDFfixedt0.lnrgng(meanlog=meanlog,sdlog=sdlog,dt=matrix(pmax(
        rep(dt,each=length(meanlog))-t0,0),nrow=length(meanlog)))/st0
    
    outs <- numeric(length(dt))
    for (i in 1:length(outs)) {
      tmp <- try(integrate(f=integrate.f,
        lower=dt[i]-st0[1],upper=dt[i],
        meanlog=meanlog,sdlog=sdlog,t0=t0,st0=st0[1])$value,silent=TRUE)
      if (is.numeric(tmp)) 
        outs[i] <- tmp else
        outs[i] <- 0
    }
    return(outs)
  }
}

# # Check
# 
# # 2 choice 
# n=1e5
# meanlog=c(.5,.75); sdlog=c(1,1); t0=.2
# sim <- rlnrgng(n=n,meanlog,sdlog,t0,st0=0)
# dns <- plot.cell.density(sim,xlim=c(0,7),save.density=TRUE)
# d <- n1PDF.lnrgng(dns$'2'$x,meanlog[c(2,1)],sdlog[c(2,1)],t0,st0=0)
# lines(dns$'2'$x,d,col="red")
# 
# # p(Stop check)
# mean(is.na(sim$RT))
# n1PDFfixedt0.lnrgng(dt=matrix(rep(NA,2),ncol=1),meanlog,sdlog)
# 
# # 3 choice
# n=1e5
# meanlog=c(.5,.75,1); sdlog=c(1,1,1); t0=.2
# sim <- rlnrgng(n=n,meanlog,sdlog,t0,st0=0)
# dns <- plot.cell.density(sim,xlim=c(0,7),save.density=TRUE)
# d <- n1PDF.lnrgng(dns$'2'$x,meanlog[c(2,1,3)],sdlog[c(2,1,3)],t0,st0=0)
# lines(dns$'2'$x,d,col="red")
# d <- n1PDF.lnrgng(dns$'3'$x,meanlog[c(3,2,1)],sdlog[c(3,2,1)],t0,st0=0)
# lines(dns$'3'$x,d,col="red",lty=2)
# 
# # p(Stop check)
# mean(is.na(sim$RT))
# n1PDFfixedt0.lnrgng(dt=matrix(rep(NA,3),ncol=1),meanlog,sdlog)


}

####################### LBA go-nogo ----
{

rlba.normgng <- function (n, A, b, t0, mean_v, sd_v, st0 = 0, posdrift = TRUE) 
# Race among length(mean_v) accumulators, first of which is a no-go 
# accumulator. For trials with winning first accumulator RT set to NA. 
{
   out <- rlba.norm(n,A,b,t0,mean_v,sd_v,st0,posdrift)
   out[out$response==1,"rt"] <- NA
   n_v <- ifelse(is.null(dim(mean_v)), length(mean_v), dim(mean_v)[1])
   out$response <- factor(out$response,levels=1:n_v)
   data.frame(out)
}


 
n1PDFfixedt0.normgng=function(dt,A,b,mean_v,sd_v,st0=0,posdrift=TRUE) 
# Same as n1PDFfixedt0 except dt=NA done by integration
{
  
  stopfn <- function(t,A,b,mean_v,sd_v,st0=0,posdrift=TRUE) 
  {
    n1PDFfixedt0.norm(
      matrix(rep(t,each=length(mean_v)),nrow=length(mean_v)),
      A=A,b=b,mean_v=mean_v,sd_v=sd_v,posdrift=posdrift
    )
  }
  
  n.trials <- dim(dt)[2]
  out <- numeric(n.trials)
  is.stop <- is.na(dt[1,])
  if (any(!is.stop)) dt[1,!is.stop] <- n1PDFfixedt0.norm(dt[,!is.stop,drop=F],
    A=A,b=b,mean_v=mean_v,sd_v=sd_v,posdrift=posdrift)
  # tmp <- try(integrate(f=stopfn,lower=0,upper=Inf,
  #     A=A,b=b,mean_v=mean_v,sd_v=sd_v,posdrift=posdrift)$value,silent=TRUE)
  # if (!is.numeric(tmp)) tmp <- 0
  tmp <- my.integrate(f=stopfn,lower=0,
      A=A,b=b,mean_v=mean_v,sd_v=sd_v,posdrift=posdrift)
  dt[1,is.na(dt[1,])] <- tmp 
  dt[1,]
}

n1PDF.normgng <- function(dt,A,b,t0,mean_v,sd_v,st0=0,posdrift=TRUE)
# Same as n1PDF except NAs dealt with by integration
{
    
  if ( st0 < 1e-3 ) # smaller values can cause numerical integration problems
    return(n1PDFfixedt0.normgng(
      A=A,b=b,mean_v=mean_v,sd_v=sd_v,posdrift=posdrift,
      dt=matrix(pmax(rep(dt,each=length(mean_v))-t0,0),nrow=length(mean_v))
    )) else
  {    
    
    integrate.f <- function(A,b,t0,mean_v,sd_v,st0,posdrift) 
      n1PDFfixedt0.normgng(
        A=A,b=b,mean_v=mean_v,sd_v=sd_v,posdrift=posdrift,
        dt=matrix(pmax(rep(dt,each=length(mean_v))-t0,0),
                  nrow=length(mean_v)))/st0
    
    outs <- numeric(length(dt))
    for (i in 1:length(outs)) {
      tmp <- try(integrate(f=integrate.f,
        lower=dt[i]-st0[1],upper=dt[i],A=A,b=b,t0=t0,mean_v=mean_v,sd_v=sd_v,
        st0=st0[1],posdrift=posdrift)$value,silent=TRUE)
      if (is.numeric(tmp)) 
        outs[i] <- tmp else
        outs[i] <- 0
    }
    return(outs)
  }
}


# # Check
# 
# # 2 Choice case
# n=1e5
# A=c(1,1);b=c(2,2);t0=.2;mean_v=c(1,0);sd_v=c(1,1);st0=0;posdrift=TRUE
# sim <- rlba.normgng(n,A,b,t0,mean_v,sd_v,st0,posdrift)
# names(sim) <- c("RT","R")
# dns <- plot.cell.density(sim,xlim=c(0,7),save.density=TRUE)
# d <- n1PDF.normgng(dt=dns$'2'$x,A=A[2:1],b=b[2:1],mean_v=mean_v[2:1],
#   sd_v=sd_v[2:1],t0=t0,st0=st0,posdrift=posdrift)
# # d <- n1PDF.normgng(dt=dns$'2'$x,A=A,b=b,mean_v=mean_v,
# #   sd_v=sd_v,t0=t0,st0=st0,posdrift=posdrift)
# 
# lines(dns$'2'$x,d,col="red")
# 
# # p(Stop check)
# mean(is.na(sim$RT))
# n1PDFfixedt0.normgng(dt=matrix(rep(NA,2),ncol=1),A=A,b=b,
#                      mean_v=mean_v,sd_v=sd_v)
# 
# # 3 Choice case
# n=1e5
# A=c(1,1,1);b=c(2,2,2);t0=.2;mean_v=c(1,.5,0);sd_v=c(1,1,1);st0=0;posdrift=TRUE
# sim <- rlba.normgng(n,A,b,t0,mean_v,sd_v,st0,posdrift)
# names(sim) <- c("RT","R")
# dns <- plot.cell.density(sim,xlim=c(0,3),save.density=TRUE)
# d2 <- n1PDF.normgng(dt=dns$'2'$x,A=A[c(2,3,1)],b=b[c(2,3,1)],mean_v=mean_v[c(2,3,1)],
#   sd_v=sd_v[c(2,3,1)],t0=t0,st0=st0,posdrift=posdrift)
# lines(dns$'2'$x,d2,col="red")
# d3 <- n1PDF.normgng(dt=dns$'3'$x,A=A[3:1],b=b[3:1],mean_v=mean_v[3:1],
#   sd_v=sd_v[3:1],t0=t0,st0=st0,posdrift=posdrift)
# lines(dns$'3'$x,d3,col="red",lty=2)
# 
# 
# # p(Stop check)
# mean(is.na(sim$RT))
# n1PDFfixedt0.normgng(dt=matrix(rep(NA,3),ncol=1),A=A,b=b,
#                      mean_v=mean_v,sd_v=sd_v)

}

####################### LNR stop signal ----
{
# NB1: no st0
  
# NB2: TRIALS effect on meanlog 

rlnrss <- function (n, meanlog, sdlog, t0, t0sg, tf=0, gf=0, ts = 0,
                    SSD=Inf, TRIALS = NA, staircase=NA) 
# Race among length(meanlog) accumulators (if meanlog a vector), 
# or dim(meanlog)[1] (if a matrix), first of which is a stop accumulator.
# Acts the same as rlnr except NA returned for RT when winner = 1. 
# Optional SSD argument can be used to adjust start time for first
# accumulator. SSD can be a scalar or vector length n; output has an SSD column 
# For trials with winning first accumulator RT and R set to NA. 
# tf = trigger failure probability, gf = go failure probability
# If any !is.na in staircase runs a staircase
# t0 is a scalar with the standard interpritaiton for GO accumulators. 
# Definition of t0sg (a non-negative scalar) depends on whether response 
# production time is assumed to be ballistic or not.  
# If it is ballistic t0sg = stop encoding - go encoding time + t0 
# If if it is NOT ballistic, t0sg = stop encoding 
# IN BOTH CASES t0sg < 0 IS NOT ALLOWED
# ts = slope of slowing (speeding if negative) over TRIALS, meanlog - ts*TRIALS
# This has a linear effect on mean and sd

{
  if ( t0sg < 0 ) stop("t0sg cannot be less than zero")  
  
  if ( length(SSD)==1 ) SSD <- rep(SSD,n)
  if ( any(is.na(SSD)) || length(SSD) != n )
    stop("SSD cannot have NAs and must be a scalar or same length as n")
 
  n_acc <- ifelse(is.null(dim(meanlog)),length(meanlog),dim(meanlog)[1])

  # t0sg -> sg for stop accumulator, relative to 0 for go accumulators
  t0S <- matrix(rep(c(t0sg-t0[1],rep(0,n_acc-1)),length.out=n*n_acc),nrow=n_acc)
  
  if (!is.matrix(meanlog)) meanlog <- matrix(rep(meanlog,n),nrow=n_acc)
  if (!is.matrix(sdlog)) sdlog <- matrix(rep(sdlog,n),nrow=n_acc)
  
  if ( !any(is.na(TRIALS)) ) {
    if (length(TRIALS)!=n)
      stop("TRIALS must have length n")
    meanlog[-1,] <- meanlog[-1,] + rep(ts*TRIALS,each=n_acc-1)
  }
  
  if ( gf > 0 ) # Setup for GO failure
    is.gf <- as.logical(rbinom(length(SSD),1,gf)) else
    is.gf <- logical(length(SSD))
  
  if ( all(!is.finite(SSD)) ) {              # ALL GO
    out <- rlnr(n,meanlog[-1,,drop=FALSE],sdlog[-1,,drop=FALSE],t0)
    out$R <- out$R+1
  } else {                                   # SOME STOP
    if ( any(is.na(staircase)) ) {           # STOP fixed SSD
      # add SSD to stop accumulator
      t0S[1,] <- t0S[1,] + SSD 
      out <- rlnr(n,meanlog,sdlog,t0S)
      if ( tf>0 ) {
        is.tf <- logical(length(SSD))
        is.tf[is.finite(SSD)][as.logical(rbinom(sum(is.finite(SSD)),1,tf))] <- TRUE  
        if ( any(is.tf) ) { 
          out[is.tf,] <- rlnr(sum(is.tf),meanlog[-1,is.tf,drop=FALSE],
            sdlog[-1,is.tf,drop=FALSE],t0=0)
          out[is.tf,"R"] <- out[is.tf,"R"]+1
        }
      }
    } else {                                 # STOP, staircase
      if ( !is.numeric(staircase) | length(staircase)!=1 )
        stop("Staircase must be a numeric vector of length 1 specifying the step.")
      SSDi <- SSD[is.finite(SSD)][1] # begining SSD 
      dt <- matrix(rlnorm(n = n*n_acc, meanlog = meanlog, sdlog = sdlog), 
                 nrow = n_acc) + t0S
      # Setup
      winner <- numeric(n)
      for ( i in c(1:n) ) {
        if ( !is.finite(SSD[i]) )   # not staircase
          dt[1,i] <- dt[1,i] + SSD[i] else
          dt[1,i] <- dt[1,i] + SSDi # staircase
        if ( runif(1)<tf ) # Trigger failure
          winner[i] <- which.min(dt[2:n_acc,i])+1 else
          winner[i] <- which.min(dt[,i])
        if (is.gf[i]) winner[i] <- 1
        if ( is.finite(SSD[i]) ) { # update staircase
          SSD[i] <- SSDi
          if ( winner[i]==1 ) 
            SSDi <- SSDi + staircase else
            SSDi <- SSDi - staircase
            if (SSDi<1e-10) SSDi <- 0
        }
      }
      out <- data.frame(RT=dt[cbind(winner,1:n)],R=winner)
    }
    out$RT <- out$RT + t0 # Add t0 for go responses
  }
  out[out$R==1,"RT"] <- NA
  if (gf > 0) {
    out$RT[is.gf] <- NA
    out$R[is.gf] <- 1
  }
  if ( any(is.na(TRIALS)) ) cbind.data.frame(out,SSD=SSD) else
                            cbind.data.frame(out,SSD=SSD,TRIALS=TRIALS)
}
 



n1PDF.lnrss <- function(rt,meanlog,sdlog,t0,t0sg,tf=0,gf=0,ts=0,
                        SSD=Inf,TRIALS=NA,Si)
# Same as n1PDF.lnr except SSD is either a scalar or vector of length(rt)
# stop accumulator must have name "NR". SSD is subtracted stop accumulator time
# and dt=NA done by integration.
#
# tf= probabiliy of trigger failure, where
# L = trigger fail & respond + trigger and respond + trigger and no-response
#   = tf*L(N-1)+(1-tf)[L(N)+p(S)],
# L(N-1) = choice race likelihood (no stop accumulator), 
# L(N) = full N unit race likelihood given they did respond, 
# p(S) probability of stop winning
#
# gf = probabiliy of go failure. 
# On go trials:   L = go fail (so no response) + go and L above 
# L = gf + (1-gf)*[tf*L(N-1)+(1-tf)[L(N)+p(S)]]  or similarly
# L =    [ p(non-response) ]    +           [ p(response) ] 
#   = [ gf + (1-gf)(1-tf)p(S) ] + [ (1-gf){(tf*Ln(n-1) + (1-tf)*L(N))} ]
#
# NB:rt is NOT decision time, but rather full RT as t0 has to be passed
#    in order to include properly in cases where RT is NA (i.e., sucessful stop)
#
# Definition of t0sg (a non-negative scalar) depends on whether response 
# production time is assumed to be ballistic or not.  
# If it is ballistic t0sg = stop encoding - go encoding time + t0 
# If if it is NOT ballistic, t0sg = stop encoding 
# IN BOTH CASES t0sg < 0 IS NOT ALLOWED (zero likelihood returned)


{
  
  stopfn <- function(t,meanlogj,sdlogj,t0,t0sg,SSD,Si) 
  {
    # d = s-g = tD-t0(GO), then add SSDstart time to get 
    # start time go - start time stop, i.e., finishing time advantage for GO
    t0S <- rep(0,length(meanlogj)) # Set relative to stop accumulator finish time
    t0S[-Si] <- t0S[-Si]+t0sg-t0+SSD   
    # subtracting min(t0S) keeps all times positive
    dt <- matrix(rep(t,each=length(meanlogj)),nrow=length(meanlogj))+t0S-min(t0S)
    i <- c(Si,c(1:length(meanlogj))[-Si])
    n1PDFfixedt0.lnr(dt[i,,drop=FALSE],meanlogj[i],sdlogj[i])
  }

  # NOTE: t0 is not subtracted when making dt but passed to handle RT=NA case
  
  # Bad t0sg
  if (t0sg<0) return(rep(0,length(rt)))
  
  if ( length(SSD)==1 ) SSD <- rep(SSD,length(rt))
  if (length(SSD) != length(rt))
    stop("SSD must be a scalar or same length as rt")
  n_acc <- ifelse(is.null(dim(meanlog)),length(meanlog),dim(meanlog)[1])
  
  rt <- matrix(rep(rt,each=n_acc),nrow=n_acc)
  is.stop <- is.na(rt[1,])  
  
  if (!is.matrix(meanlog)) meanlog <- matrix(rep(meanlog,dim(rt)[2]),nrow=n_acc)
  if (!is.matrix(sdlog)) sdlog <- matrix(rep(sdlog,dim(rt)[2]),nrow=n_acc)

  if ( any(is.na(TRIALS)) | ts == 0 ) { 
    p <- SSD[is.stop]
    pj <- c(1:sum(is.stop))[!duplicated(p)] # index of unique SSD
  } else {
    meanlog[-Si,] <- meanlog[-Si,] + ts*TRIALS
    p <- apply(
        rbind(meanlog[,is.stop,drop=FALSE],SSD[is.stop]),
      2,paste,collapse="")
    pj <- c(1:sum(is.stop))[!duplicated(p)] # index of unique p and SSD
  }
  
  if ( any(!is.stop) ) 
  {
    rt[Si,!is.stop] <- rt[Si,!is.stop] - t0sg - SSD[!is.stop]
    rt[-Si,!is.stop] <- rt[-Si,!is.stop]-t0
    if ( tf > 0 ) 
    {
      rt[1,!is.stop] <- (1-gf)*(
        tf*n1PDFfixedt0.lnr(rt[-Si,!is.stop,drop=FALSE],
          meanlog[-Si,!is.stop,drop=FALSE],sdlog[-Si,!is.stop,drop=FALSE]) +
        (1-tf)*n1PDFfixedt0.lnr(rt[,!is.stop,drop=FALSE],
          meanlog[,!is.stop,drop=FALSE],sdlog[,!is.stop,drop=FALSE])
      )
    } else 
      rt[1,!is.stop] <- (1-gf)*n1PDFfixedt0.lnr(rt[,!is.stop,drop=FALSE],
        meanlog[,!is.stop,drop=FALSE],sdlog[,!is.stop,drop=FALSE])
  }
  
  if ( any(is.stop) ) for (j in pj) {
#     tmp <- ifelse(!is.finite(SSD[j]),0,
#       try(integrate(f=stopfn,lower=0,upper=Inf,meanlogj=meanlog[,j],
#         sdlogj=sdlog[,j],t0=t0,t0sg=t0sg,SSD=SSD[j],Si=Si,
#         NoBallistic = FALSE)$value,silent=TRUE))
#     if (!is.numeric(tmp)) tmp <- 0
    if ( !is.finite(SSD[j]) ) tmp <- 0 else
      tmp <- my.integrate(f=stopfn,lower=0,meanlogj=meanlog[,j],
        sdlogj=sdlog[,j],t0=t0,t0sg=t0sg,SSD=SSD[j],Si=Si)
     rt[1,is.stop][p %in% p[j]] <- gf +(1-gf)*(1-tf)*tmp
  }
  rt[1,]
}


# VERY EXTENSIVE TESTING WITH Two different SSDs
{ 
# # ########### TWO ACCUMULATOR CASE
# 
# n=1e5
# meanlog=c(.75,.75); sdlog=c(.5,1)
# SSD = rep(c(1,10)/10,each=n/2)
# 
# # Run one of the follwing two lines
# do.trials=FALSE
# do.trials = TRUE # requires very differnet plotting check, can be SLOW!
# 
# #### RUN ONE OF THE FOLLOWING THREE LINES, all assume .2s go Ter
# t0=.2; t0sg= 0  # minimum possible value of t0sg, stop encoding .2 less than go
# t0=.2; t0sg=.2  # equal stop and go enconding times
# t0=.2; t0sg=.4  # stop .2 slower than go
# 
# ### RUN ONE OF THE FOLLOWING FOUR LINES
# # Without trigger failure or go failure
# tf=0; gf=0
# # With trigger failure, no go failure
# tf=.1;gf=0
# # Without trigger failure, with go failure
# tf=0; gf=.1
# # With trigger failure and go failure
# tf=.1;gf=.1
# 
# if (do.trials) {
#   ts=.5; TRIALS=log10(seq(1,10,length.out=n)) # 1..10 natural so 0-1 on log
#   TRIALS <- as.vector(t(matrix(TRIALS,nrow=2))) # interleave SSDs
#   # Plot slowing in GO (usually nice and linear, up to smooting overfitting)
#   sim.go <- rlnrss(n=n,meanlog,sdlog,t0,t0sg,tf=tf,gf=gf,TRIALS=TRIALS,ts=ts)
#   is.in <- !is.na(sim.go$RT) # in case go failure
#   plot(smooth.spline(TRIALS[is.in],sim.go$RT[is.in]),ylab="Smooth",xlab="TRIALS",type="l")
# } else {TRIALS=NA;ts=0}
# 
# # Simulate stop trials
# sim <- rlnrss(n=n,meanlog,sdlog,t0,t0sg,SSD=SSD,tf=tf,gf=gf,TRIALS=TRIALS,ts=ts)
# 
# # Plot densities
# par(mfrow=c(1,2))
# dns1 <- plot.cell.density(sim[sim$SSD==.1,],xlim=c(0,7),save.density=TRUE,main="SSD=.1")
# dns2 <- plot.cell.density(sim[sim$SSD!=.1,],xlim=c(0,7),save.density=TRUE,main="SSD=1")
# x1c <- dns1$'2'$x; x2c <- dns2$'2'$x
# 
# # Signal respond RT
# dat <- sim; dat <- dat[!is.na(dat$RT),]; dat$R <- factor(as.character(dat$R))
# round(tapply(dat$RT,dat[,c("R","SSD")],mean),2)
# 
# if (do.trials) {
#   tmp <- n1PDF.lnrss(sim$RT[!is.na(sim$RT)],meanlog[2:1],sdlog[2:1],t0,t0sg,
#     ts=ts,TRIALS=TRIALS[!is.na(sim$RT)],SSD=SSD[!is.na(sim$RT)],Si=2,tf=tf,gf=gf)
#   par(mfrow=c(1,2))
#   # red=black?
#   plot(x1c,dns1$'2'$y,pch=".",main="SSD=.1",ylab="Density",xlab="RT")
#   lines(smooth.spline(sim$RT[!is.na(sim$RT) & SSD==.1],
#    tmp[c(SSD==.1)[!is.na(sim$RT)]]),col="red")
#   # red=black?
#   plot(x2c,dns2$'2'$y,pch=".",main="SSD=1",ylab="Density",xlab="RT")
#   lines(smooth.spline(sim$RT[!is.na(sim$RT) & SSD==1],
#     tmp[c(SSD==1)[!is.na(sim$RT)]]),col="red")
#   print(tapply(is.na(sim$RT),sim$SSD,mean)) # empirical
#   tmp <- n1PDF.lnrss(rep(NA,n),meanlog,sdlog,t0,t0sg,SSD=SSD,Si=1,tf=tf,gf=gf,ts=ts,TRIALS=TRIALS)
#   print(mean(tmp[SSD==.1]))
#   print(mean(tmp[SSD==1]))
#   plot(TRIALS,tmp,pch=".",xlab="TRIALS",ylab="p(NA)",ylim=c(0,1))
#   lines(smooth.spline(TRIALS[SSD==.1],as.numeric(is.na(sim$RT)[SSD==.1])),col="red")
#   lines(smooth.spline(TRIALS[SSD==1],as.numeric(is.na(sim$RT)[SSD==1])),col="red")
# } else {
#   # Save simulated densities
#   r1 <- c(2,1)
#   d.r1 <- n1PDF.lnrss(rt=c(x1c,x2c),meanlog[r1],sdlog[r1],t0,t0sg,
#     SSD=c(rep(.1,length(x1c)),rep(1,length(x2c))),Si=2,tf=tf,gf=gf)
#   # Plot simulated (black) and theoretical (red) densities
#   par(mfrow=c(1,2))
#   # red=black?
#   plot(x1c,dns1$'2'$y,type="l",main="SSD=.1",ylab="Density",xlab="RT",
#      ylim=c(0,max(dns1$'2'$y)))
#   lines(x1c,d.r1[1:length(x1c)],col="red")
#   # red=black?
#   plot(x2c,dns2$'2'$y,type="l",main="SSD=1",ylab="Density",xlab="RT",
#      ylim=c(0,max(dns2$'2'$y)))
#   lines(x2c,d.r1[(length(x2c)+1):(2*length(x2c))],col="red")
# 
#   # p(Stop check)
#   print(tapply(is.na(sim$RT),sim$SSD,mean)) # empirical
#   print(n1PDF.lnrss(NA,meanlog,sdlog,t0,t0sg,SSD=.1,Si=1,tf=tf,gf=gf))
#   print(n1PDF.lnrss(NA,meanlog,sdlog,t0,t0sg,SSD=1,Si=1,tf=tf,gf=gf))
# }
# 
# 
# 
# ########### THREE ACCUMULATOR CASE
# 
# n=1e5
# meanlog=c(.75,.75,1); sdlog=c(.5,1,1)
# SSD = rep(c(1,10)/10,each=n/2)
# 
# do.trials=FALSE
# do.trials = TRUE # requires very differnet plotting check, can be SLOW!
# 
# #### RUN ONE OF THE FOLLOWING THREE LINES, all assume .2s go Ter
# t0=.2; t0sg= 0  # minimum possible value of t0sg, stop encoding .2 less than go
# t0=.2; t0sg=.2 # equal stop and go enconding times
# t0=.2; t0sg=.4 # stop .2 slower than go
# 
# ### RUN ONE OF THE FOLLOWING FOUR LINES
# # Without trigger failure or go failure
# tf=0; gf=0
# # With trigger failure, no go failure
# tf=.1;gf=0
# # Without trigger failure, with go failure
# tf=0; gf=.1
# # With trigger failure and go failure
# tf=.1;gf=.1
# 
# if (do.trials) {
#   ts=.5; TRIALS=log10(seq(1,10,length.out=n)) # 1..10 natural so 0-1 on log
#   TRIALS <- as.vector(t(matrix(TRIALS,nrow=2))) # interleave SSDs
#   # Plot slowing in GO (usually nice and linear, up to smooting overfitting)
#   sim.go <- rlnrss(n=n,meanlog,sdlog,t0,t0sg,tf=tf,gf=gf,TRIALS=TRIALS,ts=ts)
#   is.in <- !is.na(sim.go$RT) # in case go failure
#   plot(smooth.spline(TRIALS[is.in],sim.go$RT[is.in]),ylab="Smooth",xlab="TRIALS",type="l")
# } else {TRIALS=NA;ts=0}
# 
# # Simulate stop trials
# sim <- rlnrss(n=n,meanlog,sdlog,t0,t0sg,SSD=SSD,tf=tf,gf=gf,TRIALS=TRIALS,ts=ts)
# 
# par(mfrow=c(1,2))
# dns1 <- plot.cell.density(sim[sim$SSD==.1,],xlim=c(0,7),save.density=TRUE,main="SSD=.1")
# dns2 <- plot.cell.density(sim[sim$SSD!=.1,],xlim=c(0,7),save.density=TRUE,main="SSD=1")
# x1c <- dns1$'2'$x; x2c <- dns2$'2'$x
# x1e <- dns1$'3'$x; x2e <- dns2$'3'$x
# 
# # Signal respond RT
# dat <- sim; dat <- dat[!is.na(dat$RT),]; dat$R <- factor(as.character(dat$R))
# round(tapply(dat$RT,dat[,c("R","SSD")],mean),2)
# 
# if (do.trials) {
#   r1 <- c(2,1,3)
#   is.in1 <- !is.na(sim$RT) & sim$R==2
#   d.r1 <- n1PDF.lnrss(sim$RT[is.in1],meanlog[r1],ts=ts,TRIALS=TRIALS[is.in1],
#             sdlog=sdlog[r1],t0=t0,t0sg=t0sg,SSD=SSD[is.in1],Si=2,tf=tf,gf=gf)
#   r2 <- c(3,1,2)
#   is.in2 <- !is.na(sim$RT) & sim$R==3
#   d.r2 <- n1PDF.lnrss(sim$RT[is.in2],meanlog[r2],ts=ts,TRIALS=TRIALS[is.in2],
#            sdlog=sdlog[r2],t0=t0,t0sg=t0sg,SSD=SSD[is.in2],Si=2,tf=tf,gf=gf)
#   par(mfrow=c(1,3))
#   # red=black?
#   plot(x1c,dns1$'2'$y,pch=".",main="SSD=.1",ylab="Density",xlab="RT",type="l")
#   lines(x1e,dns1$'3'$y,lty=2)
#   lines(smooth.spline(sim$RT[is.in1 & sim$SSD==.1],
#                       d.r1[c(sim$SSD==.1)[is.in1]]),col="red")
#   lines(smooth.spline(sim$RT[is.in2 & sim$SSD==.1],d.r2[c(sim$SSD==.1)[is.in2]]),
#         lty=2,col="red")
#   # red=black?
#   plot(x2c,dns2$'2'$y,pch=".",main="SSD=1",ylab="Density",xlab="RT",type="l")
#   lines(x2e,dns2$'3'$y,lty=2)
#   lines(smooth.spline(sim$RT[is.in1 & sim$SSD==1],
#                       d.r1[c(sim$SSD==1)[is.in1]]),col="red")
#   lines(smooth.spline(sim$RT[is.in2 & sim$SSD==1],
#                       d.r2[c(sim$SSD==1)[is.in2]]),col="red",lty=2)
#   
#   print(tapply(is.na(sim$RT),sim$SSD,mean)) # empirical
#   tmp <- n1PDF.lnrss(rep(NA,n),meanlog,sdlog,t0,t0sg,SSD=SSD,Si=1,tf=tf,gf=gf,ts=ts,TRIALS=TRIALS)
#   print(mean(tmp[SSD==.1]))
#   print(mean(tmp[SSD==1]))
#   plot(TRIALS,tmp,pch=".",xlab="TRIALS",ylab="p(NA)",ylim=c(0,1))
#   lines(smooth.spline(TRIALS[SSD==.1],as.numeric(is.na(sim$RT)[SSD==.1])),col="red")
#   lines(smooth.spline(TRIALS[SSD==1],as.numeric(is.na(sim$RT)[SSD==1])),col="red")
# } else {
#   # Save simulated densities
#   r1 <- c(2,1,3)
#   d.r1 <- n1PDF.lnrss(rt=c(x1c,x2c),meanlog[r1],sdlog[r1],t0,t0sg,
#     SSD=c(rep(.1,length(x1c)),rep(1,length(x2c))),Si=2,tf=tf,gf=gf)
#   r2 <- c(3,1,2)
#   d.r2 <- n1PDF.lnrss(rt=c(x1e,x2e),meanlog[r2],sdlog[r2],t0,t0sg,
#     SSD=c(rep(.1,length(x1e)),rep(1,length(x2e))),Si=2,tf=tf,gf=gf)
#   # Plot simulated (black) and theoretical (red) densities
#   par(mfrow=c(1,2))
#   # red=black?
#   plot(x1c,dns1$'2'$y,type="l",main="SSD=.1",ylab="Density",xlab="RT",
#      ylim=c(0,max(dns1$'2'$y)))
#   lines(x1c,d.r1[1:length(x1c)],col="red")
#   lines(x1e,dns1$'3'$y,lty=2)
#   lines(x1e,d.r2[1:length(x1e)],col="red",lty=2)
#   # red=black?
#   plot(x2c,dns2$'2'$y,type="l",main="SSD=1",ylab="Density",xlab="RT",
#      ylim=c(0,max(dns2$'2'$y)))
#   lines(x2c,d.r1[(length(x2c)+1):(2*length(x2c))],col="red")
#   lines(x2e,dns2$'3'$y,lty=2)
#   lines(x2e,d.r2[(length(x2e)+1):(2*length(x2e))],col="red",lty=2)
# 
#   # p(Stop check)
#   print(tapply(is.na(sim$RT),sim$SSD,mean)) # empirical
#   print(n1PDF.lnrss(NA,meanlog,sdlog,t0,t0sg,SSD=.1,Si=1,tf=tf,gf=gf))
#   print(n1PDF.lnrss(NA,meanlog,sdlog,t0,t0sg,SSD=1,Si=1,tf=tf,gf=gf))
# }
}

}

####################### ExGaussian stop signal----
{
# WHY TRIAL SCALING IS BAD IN EXG, mean not proportional to sd
# TRIALS=c(0:10)/10
# mu=.5; sigma=.025; tau=.05; ts=.25
# sigma=sigma+ts*TRIALS
# tau=tau + ts*TRIALS
# mn= mu + tau 
# sd=sqrt( (sigma)^2 + (tau)^2 )
# ratio=mn/sd
# round(rbind(sigma,tau,mn,sd,ratio),3)
# ratio[1]/ratio[10]


# Modified from gamlss.dist to make cdf in nu > 0.05 * sigma case robust,
# and robust to -Inf and Inf inputs, returns NA for bad sigma or tau and
# robust against small sigma cases.
pexGAUS <- function (q, mu = 5, sigma = 1, nu = 1, lower.tail = TRUE, log.p = FALSE) 
{
  if (sigma <= 0) return(rep(NA,length(q)))
  if (nu <= 0) return(rep(NA,length(q)))
  
  # if (sigma < 0.05*nu) 
  if (sigma < 1e-4) 
    return(pexp(q-mu,1/nu,log=log.p,lower.tail=lower.tail)) # shfited exponential

  ly <- length(q)
  sigma <- rep(sigma, length = ly)
  mu <- rep(mu, length = ly)
  nu <- rep(nu, length = ly)
  index <- seq(along = q)
  z <- q - mu - ((sigma^2)/nu)
  cdf <- ifelse(is.finite(q), 
      ifelse(nu > 0.05 * sigma, 
        pnorm((q - mu)/sigma) - 
          exp(log(pnorm(z/sigma)) + ((mu + (sigma^2/nu))^2 - (mu^2) - 
            2 * q * ((sigma^2)/nu))/(2 * sigma^2)), 
        pnorm(q, mean = mu, sd = sigma)),
      ifelse(q<0,0,1)   
    )
  if (lower.tail == TRUE) 
      cdf <- cdf
    else cdf <- 1 - cdf
  if (log.p == FALSE) 
      cdf <- cdf
    else cdf <- log(cdf)
  cdf
}

# gamlss.dist function, but returns NA for bad sigma or tau, and
# robust against small sigma cases.
dexGAUS <- function (x, mu = 5, sigma = 1, nu = 1, log = FALSE) 
{
    if (sigma <= 0) return(rep(NA,length(x)))
    if (nu <= 0) return(rep(NA,length(x)))
  
    # if (sigma < 0.05*nu) 
    if (sigma < 1e-4) 
      return(dexp(x-mu,1/nu,log=log)) # shfited exponential

    ly <- length(x)
    sigma <- rep(sigma, length = ly)
    mu <- rep(mu, length = ly)
    nu <- rep(nu, length = ly)
    z <- x - mu - ((sigma^2)/nu)
    logfy <- ifelse(nu > 0.05 * sigma, -log(nu) - (z + (sigma^2/(2 * 
        nu)))/nu + log(pnorm(z/sigma)), dnorm(x, mean = mu, sd = sigma, 
        log = TRUE))
    if (log == FALSE) 
        fy <- exp(logfy)
    else fy <- logfy
    fy
}

rexg <- function (mu,sigma,tau) 
# NOTE: gamlss.dist rexGAUS is very slow so didnt use.
# Ex-gaussian race, mu is a matrix with 1 row per accumulator, columns
# are trials, ouput is a two column (RT, R) data frame, on row for each trial.
# Sigma and tau can be vectors with one value, or one value for each accumulator 
# or a matrix in the same form as mu. NB: CAN PRODUCE NEGATIVE RTS!
{
    dt <- matrix(rnorm(n=length(mu), mean=mu,sd=sigma) +
                 rexp(n=length(mu),rate=1/tau),nrow = dim(mu)[1])
    winner <- apply(dt,2,which.min)    
    data.frame(RT=dt[cbind(winner,1:dim(mu)[2])],R=winner)
}

n1PDF.exg <- function(dt,mu,sigma,tau)
# Generates defective PDF for responses on node= 1
# dt (decison time) is a matrix with length(mu) rows, one row for
# each accumulator to allow for different start times
{
  
  dt[1,] <- dexGAUS(dt[1,],mu[1],sigma[1],tau[1])
  if (length(mu)>1) for (i in 2:length(mu))
    dt[1,] <- dt[1,]*pexGAUS(q=dt[i,],mu=mu[i],sigma=sigma[i],nu=tau[i],lower.tail=FALSE)
  dt[1,]
}


rexgss <- function (n, mu, sigma, tau, tf=0, gf=0, 
                    SSD=Inf, staircase=NA) 
# Race among n accumulators, first of which is a stop accumulator.
# NA returned for RT when winner = 1. Optional SSD arguement can be used to 
# adjust mu for first accumulator to mu+SSD. SSD can be a scalar or vector 
# length n. For trials with winning first accumulator RT and R set to NA. 
# Adds SSD column to output. 
# tf = trigger failure probability, gf = go failure probability
{
  if ( length(SSD)==1 ) SSD <- rep(SSD,n)
  if ( any(is.na(SSD)) || length(SSD) != n )
    stop("SSD cannot have NAs and must be a scalar or same length as n")
  if ( !is.matrix(mu) ) 
    mu <- matrix(rep(mu,times=n),nrow=length(mu)) 
  if (gf > 0) # Setup for GO failure
    is.gf <- as.logical(rbinom(length(SSD),1,gf)) else
    is.gf <- logical(length(SSD))
    
  if ( all(!is.finite(SSD)) ) {              # ALL GO
    mu[1,] <- mu[1,] + SSD
    out <- rexg(mu,sigma,tau)
  } else {                                   # SOME STOP
    if ( any(is.na(staircase)) ) {           # STOP fixed SSD
      mu[1,] <- mu[1,] + SSD
      out <- rexg(mu,sigma,tau)
      if ( tf>0 ) {
        is.tf <- logical(length(SSD))
        is.tf[is.finite(SSD)][as.logical(rbinom(sum(is.finite(SSD)),1,tf))] <- TRUE  
        if ( any(is.tf) ) { 
          out[is.tf,] <- 
            rexg(mu[-1,is.tf,drop=FALSE],sigma[-1],tau[-1])
          out[is.tf,"R"] <- out[is.tf,"R"]+1
        }
      }
    } else {                                 # STOP, staircase
      if ( !is.numeric(staircase) | length(staircase)!=1 )
        stop("Staircase must be a numeric vector of length 1 specifying the step.")
      n_acc <- dim(mu)[1]
      dt <- matrix(rnorm(n=length(mu), mean=mu,sd=sigma) +
                 rexp(n=length(mu),rate=1/tau),nrow = dim(mu)[1])
      winner <- numeric(n)
      for (i in c(1:n)) {
        dt[1,i] <- dt[1,i] + SSD[i]
        if ( runif(1)<tf ) # Trigger failure
          winner[i] <- which.min(dt[2:n_acc,i])+1 else
          winner[i] <- which.min(dt[,i])
        if (is.gf[i]) winner[i] <- 1
        if (i!=n) if (winner[i]==1) 
          SSD[i+1] <- SSD[i] + staircase else
          SSD[i+1] <- pmax(SSD[i] - staircase,0)
      }
      out <- data.frame(RT=dt[cbind(winner,1:n)],R=winner)
    }
  }
  out[out$R==1,"RT"] <- NA
  if (gf > 0) {
    out$RT[is.gf] <- NA
    out$R[is.gf] <- 1
  }
  cbind.data.frame(out,SSD=SSD)
}
 

n1PDF.exgss=function(dt,mu,sigma,tau,tf=0,gf=0,
                     SSD,Si) 
# SSD is either a scalar or vector of length(dt)
# stop accumulator must have name "NR"
# SSD is subtracted from dt[Si,]
# (i.e., stop accumulator RT) and dt=NA done by integration.
# ts = slope of slowing (speeding if negative) over TRIALS, linear affect on 
# mean and sd:  sigma + ts*TRIALS, tau + ts*trials (truncated to be positive)
#
# tf= probabiliy of trigger failure, where
# L = trigger fail & respond + trigger and respond + trigger and no-response
#   = tf*L(N-1)+(1-tf)[L(N)+p(S)],
# L(N-1) = choice race likelihood (no stop accumulator), 
# L(N) = full N unit race likelihood given they did respond, 
# p(S) probability of stop winning
#
# gf = probabiliy of go failure. 
# On go trials:   L = go fail (so no response) + go and L above 
# L = gf + (1-gf)*[tf*L(N-1)+(1-tf)[L(N)+p(S)]]  or similarly
# L =    [ p(non-response) ]    +           [ p(response) ] 
#   = [ pf + (1-gf)(1-tf)p(S) ] + [ (1-gf){(tf*Ln(n-1) + (1-tf)*L(N))} ]
{
  
  stopfn <- function(t,mu,sigma,tau,SSD,Si) 
  {
    dt <- matrix(rep(t+SSD,each=length(mu)),nrow=length(mu))
    dt[Si,] <- dt[Si,]-SSD
    i <- c(Si,c(1:length(mu))[-Si])
    n1PDF.exg(dt[i,,drop=FALSE],mu[i],sigma[i],tau[i])
  }
  
  dt=matrix(rep(dt,each=length(mu)),nrow=length(mu))
  
  is.stop <- is.na(dt[1,])  
  dt[Si,] <- dt[Si,] - SSD
  if ( any(!is.stop) ) 
  {
    if ( tf > 0 ) 
    {
      dt[1,!is.stop] <- (1-gf)*(
        tf*n1PDF.exg(dt[-Si,!is.stop,drop=FALSE],mu[-Si],sigma[-Si],tau[-Si]) +
        (1-tf)*n1PDF.exg(dt[,!is.stop,drop=FALSE],mu,sigma,tau))
    } else 
      dt[1,!is.stop] <- (1-gf)*n1PDF.exg(dt[,!is.stop,drop=FALSE],mu,sigma,tau)
  }
  if ( any(is.stop) ) for ( i in unique(SSD[is.stop]) ) {
    # tmp <- ifelse(!is.finite(i),0,
    #   try(integrate(f=stopfn,lower=-Inf,upper=Inf,
    #   mu=mu,sigma=sigma,tau=tau,SSD=i,Si=Si)$value,silent=TRUE))
    # if (!is.numeric(tmp)) tmp <- 0
    tmp <- ifelse(!is.finite(i),0,
      my.integrate(f=stopfn,lower=-Inf,
                   mu=mu,sigma=sigma,tau=tau,SSD=i,Si=Si))
    dt[1,is.stop & (SSD==i)] <- gf + (1-gf)*(1-tf)*tmp 
  }
  dt[1,]
}


# ########### TWO ACCUMULATOR CASE
# 
# # Check, two different SSDs 
# n <- 1e5
# SSD <- rep(c(1,10)/10,each=n/2)
# TRIALS <- NA
# 
# # Stop and one go accumulator
# mu=c(.75,1); sigma=c(.25,.25); tau=c(.25,.5)
# 
# ### RUN ONE OF THE FOLLOWING FOUR LINES
# # Without trigger failure or go failure
# tf=0; gf=0
# # With trigger failure, no go failure
# tf=.1;gf=0
# # Without trigger failure, with go failure
# tf=0; gf=.1
# # With trigger failure and go failure
# tf=.1;gf=.1
# 
# # Simulate data and get simlate stop rate
# sim <- rexgss(n=n,mu,sigma,tau,SSD=SSD,tf=tf,gf=gf,TRIALS=TRIALS,ts=ts)
# # Plot data
# par(mfrow=c(1,2))
# dns1 <- plot.cell.density(sim[sim$SSD==.1,],xlim=c(0,7),save.density=TRUE,main="SSD=.1")
# dns2 <- plot.cell.density(sim[sim$SSD!=.1,],xlim=c(0,7),save.density=TRUE,main="SSD=1")
# 
# # Signal respond RT
# dat <- sim; dat <- dat[!is.na(dat$RT),]; dat$R <- factor(as.character(dat$R))
# round(tapply(dat$RT,dat[,c("R","SSD")],mean),2)
# 
# # Save simulated densities
# x1 <- dns1$'2'$x; x2 <- dns2$'2'$x
# SSD <- c(rep(.1,length(x1)),rep(1,length(x2)))
# r1 <- c(2,1)
# d.r1 <- n1PDF.exgss(dt=c(x1,x2),mu=mu[r1],sigma=sigma[r1],tau=tau[r1],
#                     SSD=SSD,Si=2,tf=tf,gf=gf)
# 
# # Plot simulated (black) and theoretical (red) densities
# par(mfrow=c(1,2))
# # red=black?
# plot(x1,dns1$'2'$y,type="l",main="SSD=.1",ylab="Density",xlab="RT",
#      ylim=c(0,max(dns1$'2'$y)))
# lines(x1,d.r1[1:length(x1)],col="red")
# # red=black?
# plot(x2,dns2$'2'$y,type="l",main="SSD=1",ylab="Density",xlab="RT",
#      ylim=c(0,max(dns2$'2'$y)))
# lines(x2,d.r1[(length(x2)+1):(2*length(x2))],col="red")
# 
# # p(Stop check)
# tapply(is.na(sim$RT),sim$SSD,mean) # empirical
# # Theoretical
# n1PDF.exgss(NA,mu,sigma,tau,SSD=.1,Si=1,tf=tf,gf=gf)
# n1PDF.exgss(NA,mu,sigma,tau,SSD=1,Si=1,tf=tf,gf=gf)
# 
# ########### THREE ACCUMULATOR CASE
# 
# # Check, two different SSDs 
# n=1e5
# SSD = rep(c(1,10)/10,each=n/2)
# 
# # Stop, first go accumulator correct, second error
# mu=c(.75,1,1.25); sigma=c(.25,.25,.25); tau=c(.25,.5,.5)
# 
# ### RUN ONE OF THE FOLLOWING FOUR LINES
# # Without trigger failure or go failure
# tf=0; gf=0
# # With trigger failure, no go failure
# tf=.1;gf=0
# # Without trigger failure, with go failure
# tf=0; gf=.1
# # With trigger failure and go failure
# tf=.1;gf=.1
# 
# # Simulate data and get simlate stop rate
# sim <- rexgss(n=n,mu,sigma,tau,SSD=SSD,tf=tf,gf=gf)
# # Plot data
# par(mfrow=c(1,2))
# dns1 <- plot.cell.density(sim[sim$SSD==.1,],xlim=c(0,7),save.density=TRUE,main="SSD=.1")
# dns2 <- plot.cell.density(sim[sim$SSD!=.1,],xlim=c(0,7),save.density=TRUE,main="SSD=1")
# 
# # Signal respond RT
# dat <- sim; dat <- dat[!is.na(dat$RT),]; dat$R <- factor(as.character(dat$R))
# round(tapply(dat$RT,dat[,c("R","SSD")],mean),2)
# 
# # Save simulated densities
# x1c <- dns1$'2'$x; x2c <- dns2$'2'$x
# x1e <- dns1$'3'$x; x2e <- dns2$'3'$x
# 
# SSD <- c(rep(.1,length(x1c)),rep(1,length(x2c)))
# r1 <- c(2,1,3)
# d.r1 <- n1PDF.exgss(dt=c(x1c,x2c),mu=mu[r1],sigma=sigma[r1],tau=tau[r1],
#                     SSD=SSD,Si=2,tf=tf,gf=gf)
# SSD <- c(rep(.1,length(x1e)),rep(1,length(x2e)))
# r2 <- c(3,1,2)
# d.r2 <- n1PDF.exgss(dt=c(x1e,x2e),mu=mu[r2],sigma=sigma[r2],tau=tau[r2],
#                     SSD=SSD,Si=2,tf=tf,gf=gf)
# 
# # Plot simulated (black) and theoretical (red) densities
# par(mfrow=c(1,2))
# # red=black?
# plot(x1c,dns1$'2'$y,type="l",main="SSD=.1",ylab="Density",xlab="RT",
#      ylim=c(0,max(dns1$'2'$y)))
# lines(x1c,d.r1[1:length(x1c)],col="red")
# lines(x1e,dns1$'3'$y,lty=2)
# lines(x1e,d.r2[1:length(x1e)],col="red",lty=2)
# # red=black?
# plot(x2c,dns2$'2'$y,type="l",main="SSD=1",ylab="Density",xlab="RT",
#      ylim=c(0,max(dns2$'2'$y)))
# lines(x2c,d.r1[(length(x2c)+1):(2*length(x2c))],col="red")
# lines(x2e,dns2$'3'$y,lty=2)
# lines(x2e,d.r2[(length(x2e)+1):(2*length(x2e))],col="red",lty=2)
# 
# # p(Stop check)
# tapply(is.na(sim$RT),sim$SSD,mean) # empirical
# # Theoretical
# n1PDF.exgss(NA,mu,sigma,tau,SSD=.1,Si=1,tf=tf,gf=gf)
# n1PDF.exgss(NA,mu,sigma,tau,SSD=1,Si=1,tf=tf,gf=gf)
}

####################### Wald stop signal ----
{
# NB1: no st0
  
# NB2: TRIALS effect on B (threshold), and values < 0 set to 0 

rWaldss <- function (n, v, B, t0, t0sg, A=0, tf=0, gf=0, ts = 0,
                    SSD=Inf, TRIALS = NA, staircase=NA) 
# Race among length(v) accumulators (if v a vector), 
# or dim(v)[1] (if a matrix), first of which is a stop accumulator.
# Acts the same as rWald except NA returned for RT when winner = 1. 
# Optional SSD argument can be used to adjust start time for first
# accumulator. SSD can be a scalar or vector length n; output has an SSD column 
# For trials with winning first accumulator RT and R set to NA. 
# tf = trigger failure probability, gf = go failure probability
# If any !is.na in staircase runs a staircase
# t0 is a scalar with the standard interpritaiton for GO accumulators. 
# Definition of t0sg (a non-negative scalar) depends on whether response 
# production time is assumed to be ballistic or not.  
# If it is ballistic t0sg = stop encoding - go encoding time + t0 
# If if it is NOT ballistic, t0sg = stop encoding 
# IN BOTH CASES t0sg < 0 IS NOT ALLOWED
# ts = slope of slowing (speeding if negative) over TRIALS, meanlog - ts*TRIALS
# This has a linear effect on mean and sd

{
  if ( t0sg < 0 ) stop("t0sg cannot be less than zero")  
  
  if ( length(SSD)==1 ) SSD <- rep(SSD,n)
  if ( any(is.na(SSD)) || length(SSD) != n )
    stop("SSD cannot have NAs and must be a scalar or same length as n")
 
  n_acc <- ifelse(is.null(dim(v)),length(v),dim(v)[1])

  # t0sg -> sg for stop accumulator, relative to 0 for go accumulators
  t0S <- matrix(rep(c(t0sg-t0[1],rep(0,n_acc-1)),length.out=n*n_acc),nrow=n_acc)
  
  if (!is.matrix(v)) v <- matrix(rep(v,n),nrow=n_acc)
  if (!is.matrix(B)) B <- matrix(rep(B,n),nrow=n_acc)
  if (!is.matrix(A)) A <- matrix(rep(A,n),nrow=n_acc)
  
  if ( !any(is.na(TRIALS)) ) {
    if (length(TRIALS)!=n)
      stop("TRIALS must have length n")
    B[-1,] <- B[-1,] + rep(ts*TRIALS,each=n_acc-1)
  }
  
  if ( gf > 0 ) # Setup for GO failure
    is.gf <- as.logical(rbinom(length(SSD),1,gf)) else
    is.gf <- logical(length(SSD))
  
  if ( all(!is.finite(SSD)) ) {              # ALL GO
    out <- rWaldRace(n,v=v[-1,,drop=FALSE],B=B[-1,,drop=FALSE],A=A[-1,,drop=FALSE],t0=t0)
    out$R <- out$R+1
  } else {                                   # SOME STOP
    if ( any(is.na(staircase)) ) {           # STOP fixed SSD
      # add SSD to stop accumulator
      t0S[1,] <- t0S[1,] + SSD 
      out <- rWaldRace(n,v=v,B=B,A=A,t0=t0S)
      if ( tf>0 ) {
        is.tf <- logical(length(SSD))
        is.tf[is.finite(SSD)][as.logical(rbinom(sum(is.finite(SSD)),1,tf))] <- TRUE  
        if ( any(is.tf) ) { 
          out[is.tf,] <- rWaldRace(sum(is.tf),v=v[-1,is.tf,drop=FALSE],
            B=B[-1,is.tf,drop=FALSE],A=A[-1,is.tf,drop=FALSE],t0=0)
          out[is.tf,"R"] <- out[is.tf,"R"]+1
        }
      }
    } else {                                 # STOP, staircase
      if ( !is.numeric(staircase) | length(staircase)!=1 )
        stop("Staircase must be a numeric vector of length 1 specifying the step.")
      SSDi <- SSD[is.finite(SSD)][1] # begining SSD 
      dt <- rWaldRace(n,v=v,B=B,A=A,t0=t0S,return.ttf=TRUE)
      # Setup
      winner <- numeric(n)
      for ( i in c(1:n) ) {
        if ( !is.finite(SSD[i]) )   # not staircase
          dt[1,i] <- dt[1,i] + SSD[i] else
          dt[1,i] <- dt[1,i] + SSDi # staircase
        if ( runif(1)<tf ) # Trigger failure
          winner[i] <- which.min(dt[2:n_acc,i])+1 else
          winner[i] <- which.min(dt[,i])
        if (is.gf[i]) winner[i] <- 1
        if ( is.finite(SSD[i]) ) { # update staircase
          SSD[i] <- SSDi
          if ( winner[i]==1 ) 
            SSDi <- SSDi + staircase else
            SSDi <- SSDi - staircase
            if (SSDi<1e-10) SSDi <- 0
        }
      }
      out <- data.frame(RT=dt[cbind(winner,1:n)],R=winner)
    }
    out$RT <- out$RT + t0 # Add t0 for go responses
  }
  
  # print(out)
  
  out[out$R==1,"RT"] <- NA
  if ( gf > 0 ) {
    out$RT[is.gf] <- NA
    out$R[is.gf] <- 1
  }
  if ( any(is.na(TRIALS)) ) cbind.data.frame(out,SSD=SSD) else
                            cbind.data.frame(out,SSD=SSD,TRIALS=TRIALS)
}
 



n1PDF.Waldss <- function(rt,v,B,t0,t0sg,A=0,tf=0,gf=0,ts=0,
                        SSD=Inf,TRIALS=NA,Si)
# Same as n1Wald except SSD is either a scalar or vector of length(rt)
# stop accumulator must have name "NR". SSD is subtracted stop accumulator time
# and dt=NA done by integration.
#
# tf= probabiliy of trigger failure, where
# L = trigger fail & respond + trigger and respond + trigger and no-response
#   = tf*L(N-1)+(1-tf)[L(N)+p(S)],
# L(N-1) = choice race likelihood (no stop accumulator), 
# L(N) = full N unit race likelihood given they did respond, 
# p(S) probability of stop winning
#
# gf = probabiliy of go failure. 
# On go trials:   L = go fail (so no response) + go and L above 
# L = gf + (1-gf)*[tf*L(N-1)+(1-tf)[L(N)+p(S)]]  or similarly
# L =    [ p(non-response) ]    +           [ p(response) ] 
#   = [ gf + (1-gf)(1-tf)p(S) ] + [ (1-gf){(tf*Ln(n-1) + (1-tf)*L(N))} ]
#
# NB:rt is NOT decision time, but rather full RT as t0 has to be passed
#    in order to include properly in cases where RT is NA (i.e., sucessful stop)
#
# Definition of t0sg (a non-negative scalar) depends on whether response 
# production time is assumed to be ballistic or not.  
# If it is ballistic t0sg = stop encoding - go encoding time + t0 
# If if it is NOT ballistic, t0sg = stop encoding 
# IN BOTH CASES t0sg < 0 IS NOT ALLOWED (zero likelihood returned)


{
  
  stopfn <- function(t,vj,Bj,Aj,t0,t0sg,SSD,Si) 
  {
    # d = s-g = tD-t0(GO), then add SSDstart time to get 
    # start time go - start time stop, i.e., finishing time advantage for GO
    t0S <- rep(0,length(vj)) # Set relative to stop accumulator finish time
    t0S[-Si] <- t0S[-Si]+t0sg-t0+SSD   
    # subtracting min(t0S) keeps all times positive
    dt <- matrix(rep(t,each=length(vj)),nrow=length(vj))+t0S-min(t0S)
    i <- c(Si,c(1:length(vj))[-Si])
    n1Wald(dt[i,,drop=FALSE],v=vj[i],B=Bj[i],A=Aj[i])
  }

  # NOTE: t0 is not subtracted when making dt but passed to handle RT=NA case
  
  # Bad t0sg
  if (t0sg<0) return(rep(0,length(rt)))
  
  if ( length(SSD)==1 ) SSD <- rep(SSD,length(rt))
  if (length(SSD) != length(rt))
    stop("SSD must be a scalar or same length as rt")
  n_acc <- ifelse(is.null(dim(v)),length(v),dim(v)[1])
  
  rt <- matrix(rep(rt,each=n_acc),nrow=n_acc)
  is.stop <- is.na(rt[1,])  
  
  if (!is.matrix(v)) v <- matrix(rep(v,dim(rt)[2]),nrow=n_acc)
  if (!is.matrix(B)) B <- matrix(rep(B,dim(rt)[2]),nrow=n_acc)
  if (!is.matrix(A)) A <- matrix(rep(A,dim(rt)[2]),nrow=n_acc)

  if ( any(is.na(TRIALS)) | ts == 0 ) { 
    p <- SSD[is.stop]
    pj <- c(1:sum(is.stop))[!duplicated(p)] # index of unique SSD
  } else {
    B[-Si,] <- B[-Si,] + ts*TRIALS
    p <- apply(
        rbind(B[,is.stop,drop=FALSE],SSD[is.stop]),
      2,paste,collapse="")
    pj <- c(1:sum(is.stop))[!duplicated(p)] # index of unique p and SSD
  }
  
  if ( any(!is.stop) ) 
  {
    rt[Si,!is.stop] <- rt[Si,!is.stop] - t0sg - SSD[!is.stop]
    rt[-Si,!is.stop] <- rt[-Si,!is.stop]-t0
    if ( tf > 0 ) 
    {
      rt[1,!is.stop] <- (1-gf)*(
        tf*n1Wald(rt[-Si,!is.stop,drop=FALSE],v=v[-Si,!is.stop,drop=FALSE],
          A=A[-Si,!is.stop,drop=FALSE],B=B[-Si,!is.stop,drop=FALSE]) +
        (1-tf)*n1Wald(rt[,!is.stop,drop=FALSE],v=v[,!is.stop,drop=FALSE],
          B=B[,!is.stop,drop=FALSE],A=A[,!is.stop,drop=FALSE])
      )
    } else 
      rt[1,!is.stop] <- (1-gf)*n1Wald(dt=rt[,!is.stop,drop=FALSE],
        v=v[,!is.stop,drop=FALSE],B=B[,!is.stop,drop=FALSE],
        A=A[,!is.stop,drop=FALSE])
  }
  
  if ( any(is.stop) ) for (j in pj) {
    if ( !is.finite(SSD[j]) ) tmp <- 0 else
      tmp <- my.integrate(f=stopfn,lower=0,vj=v[,j],
        Bj=B[,j],Aj=A[,j],t0=t0,t0sg=t0sg,SSD=SSD[j],Si=Si)
     rt[1,is.stop][p %in% p[j]] <- gf +(1-gf)*(1-tf)*tmp
  }
  rt[1,]
}


# # VERY EXTENSIVE TESTING WITH Two different SSDs
# {
# # ########### TWO ACCUMULATOR CASE
# {
# n=1e4
# # n=10
# v=c(.5,1); B=c(1,1); A=c(1,1)
# SSD = rep(c(1,10)/10,each=n/2)
# 
# # Run one of the follwing two lines
# do.trials=FALSE
# do.trials = TRUE # requires very differnet plotting check, can be SLOW!
# 
# #### RUN ONE OF THE FOLLOWING THREE LINES, all assume .2s go Ter
# t0=.2; t0sg= 0  # minimum possible value of t0sg, stop encoding .2 less than go
# t0=.2; t0sg=.2  # equal stop and go enconding times
# t0=.2; t0sg=.4  # stop .2 slower than go
# 
# ### RUN ONE OF THE FOLLOWING FOUR LINES
# # Without trigger failure or go failure
# tf=0; gf=0
# # With trigger failure, no go failure
# tf=.1;gf=0
# # Without trigger failure, with go failure
# tf=0; gf=.1
# # With trigger failure and go failure
# tf=.1;gf=.1
# 
# if (do.trials) {
#   ts=.5; TRIALS=log10(seq(1,10,length.out=n)) # 1..10 natural so 0-1 on log
#   TRIALS <- as.vector(t(matrix(TRIALS,nrow=2))) # interleave SSDs
#   # Plot slowing in GO (usually nice and linear, up to smooting overfitting)
#   sim.go <- rWaldss(n=n,v=v,B=B,A=A,t0=t0,t0sg=t0sg,tf=tf,gf=gf,SSD=SSD,TRIALS=TRIALS,ts=ts)
#   is.in <- !is.na(sim.go$RT) # in case go failure
#   plot(smooth.spline(TRIALS[is.in],sim.go$RT[is.in]),ylab="Smooth",xlab="TRIALS",type="l")
# } else {TRIALS=NA;ts=0}
# 
# # Simulate stop trials
# sim <- rWaldss(n=n,v=v,B=B,A=A,t0=t0,t0sg=t0sg,tf=tf,gf=gf,SSD=SSD,TRIALS=TRIALS,ts=ts)
# 
# # Plot densities
# par(mfrow=c(1,2))
# dns1 <- plot.cell.density(sim[sim$SSD==.1,],xlim=c(0,7),save.density=TRUE,main="SSD=.1")
# dns2 <- plot.cell.density(sim[sim$SSD!=.1,],xlim=c(0,7),save.density=TRUE,main="SSD=1")
# x1c <- dns1$'2'$x; x2c <- dns2$'2'$x
# 
# # Signal respond RT
# dat <- sim; dat <- dat[!is.na(dat$RT),]; dat$R <- factor(as.character(dat$R))
# round(tapply(dat$RT,dat[,c("R","SSD")],mean),2)
# 
# if (do.trials) {
#   tmp <- n1PDF.Waldss(sim$RT[!is.na(sim$RT)],v=v[2:1],B=B[2:1],A=A[2:1],t0=t0,t0sg=t0sg,
#     ts=ts,TRIALS=TRIALS[!is.na(sim$RT)],SSD=SSD[!is.na(sim$RT)],Si=2,tf=tf,gf=gf)
#   par(mfrow=c(1,2))
#   # red=black?
#   plot(x1c,dns1$'2'$y,pch=".",main="SSD=.1",ylab="Density",xlab="RT")
#   lines(smooth.spline(sim$RT[!is.na(sim$RT) & SSD==.1],
#    tmp[c(SSD==.1)[!is.na(sim$RT)]]),col="red")
#   # red=black?
#   plot(x2c,dns2$'2'$y,pch=".",main="SSD=1",ylab="Density",xlab="RT")
#   lines(smooth.spline(sim$RT[!is.na(sim$RT) & SSD==1],
#     tmp[c(SSD==1)[!is.na(sim$RT)]]),col="red")
#   print(tapply(is.na(sim$RT),sim$SSD,mean)) # empirical
#   tmp <- n1PDF.Waldss(rep(NA,n),v=v,B=B,A=A,t0=t0,t0sg=t0sg,
#     SSD=SSD,Si=1,tf=tf,gf=gf,ts=ts,TRIALS=TRIALS)
#   print(mean(tmp[SSD==.1]))
#   print(mean(tmp[SSD==1]))
#   plot(TRIALS,tmp,pch=".",xlab="TRIALS",ylab="p(NA)",ylim=c(0,1))
#   lines(smooth.spline(TRIALS[SSD==.1],as.numeric(is.na(sim$RT)[SSD==.1])),col="red")
#   lines(smooth.spline(TRIALS[SSD==1],as.numeric(is.na(sim$RT)[SSD==1])),col="red")
# } else {
#   # Save simulated densities
#   r1 <- c(2,1)
#   d.r1 <- n1PDF.Waldss(rt=c(x1c,x2c),v=v[r1],B=B[r1],A=A[r1],t0=t0,t0sg=t0sg,
#     SSD=c(rep(.1,length(x1c)),rep(1,length(x2c))),Si=2,tf=tf,gf=gf)
#   # Plot simulated (black) and theoretical (red) densities
#   par(mfrow=c(1,2))
#   # red=black?
#   plot(x1c,dns1$'2'$y,type="l",main="SSD=.1",ylab="Density",xlab="RT",
#      ylim=c(0,max(dns1$'2'$y)))
#   lines(x1c,d.r1[1:length(x1c)],col="red")
#   # red=black?
#   plot(x2c,dns2$'2'$y,type="l",main="SSD=1",ylab="Density",xlab="RT",
#      ylim=c(0,max(dns2$'2'$y)))
#   lines(x2c,d.r1[(length(x2c)+1):(2*length(x2c))],col="red")
# 
#   # p(Stop check)
#   print(tapply(is.na(sim$RT),sim$SSD,mean)) # empirical
#   print(n1PDF.Waldss(NA,v=v,A=A,B=B,t0=t0,t0sg=t0sg,SSD=.1,Si=1,tf=tf,gf=gf))
#   print(n1PDF.Waldss(NA,v=v,A=A,B=B,t0=t0,t0sg=t0sg,SSD=1,Si=1,tf=tf,gf=gf))
# }
# 
# }
# 
# ########### THREE ACCUMULATOR CASE
# {
# n=1e4
# v=c(.5,1,.5); B=c(1,1,1); A=c(1,1,1)
# SSD = rep(c(1,10)/10,each=n/2)
# 
# do.trials=FALSE
# do.trials = TRUE # requires very differnet plotting check, can be SLOW!
# 
# #### RUN ONE OF THE FOLLOWING THREE LINES, all assume .2s go Ter
# t0=.2; t0sg= 0  # minimum possible value of t0sg, stop encoding .2 less than go
# t0=.2; t0sg=.2 # equal stop and go enconding times
# t0=.2; t0sg=.4 # stop .2 slower than go
# 
# ### RUN ONE OF THE FOLLOWING FOUR LINES
# # Without trigger failure or go failure
# tf=0; gf=0
# # With trigger failure, no go failure
# tf=.1;gf=0
# # Without trigger failure, with go failure
# tf=0; gf=.1
# # With trigger failure and go failure
# tf=.1;gf=.1
# 
# if (do.trials) {
#   ts=.5; TRIALS=log10(seq(1,10,length.out=n)) # 1..10 natural so 0-1 on log
#   TRIALS <- as.vector(t(matrix(TRIALS,nrow=2))) # interleave SSDs
#   # Plot slowing in GO (usually nice and linear, up to smooting overfitting)
#   sim.go <- rWaldss(n=n,v=v,B=B,A=A,t0=t0,t0sg=t0sg,tf=tf,gf=gf,TRIALS=TRIALS,ts=ts)
#   is.in <- !is.na(sim.go$RT) # in case go failure
#   plot(smooth.spline(TRIALS[is.in],sim.go$RT[is.in]),ylab="Smooth",xlab="TRIALS",type="l")
# } else {TRIALS=NA;ts=0}
# 
# # Simulate stop trials
# sim <- rWaldss(n=n,v=v,B=B,A=A,t0=t0,t0sg=t0sg,tf=tf,gf=gf,TRIALS=TRIALS,ts=ts,SSD=SSD)
# 
# 
# par(mfrow=c(1,2))
# dns1 <- plot.cell.density(sim[sim$SSD==.1,],xlim=c(0,7),save.density=TRUE,main="SSD=.1")
# dns2 <- plot.cell.density(sim[sim$SSD!=.1,],xlim=c(0,7),save.density=TRUE,main="SSD=1")
# x1c <- dns1$'2'$x; x2c <- dns2$'2'$x
# x1e <- dns1$'3'$x; x2e <- dns2$'3'$x
# 
# # Signal respond RT
# dat <- sim; dat <- dat[!is.na(dat$RT),]; dat$R <- factor(as.character(dat$R))
# round(tapply(dat$RT,dat[,c("R","SSD")],mean),2)
# 
# if (do.trials) {
#   r1 <- c(2,1,3)
#   is.in1 <- !is.na(sim$RT) & sim$R==2
#   d.r1 <- n1PDF.Waldss(sim$RT[is.in1],v=v[r1],ts=ts,TRIALS=TRIALS[is.in1],
#           B=B[r1],A=A[r1],t0=t0,t0sg=t0sg,SSD=SSD[is.in1],Si=2,tf=tf,gf=gf)
#   r2 <- c(3,1,2)
#   is.in2 <- !is.na(sim$RT) & sim$R==3
#   d.r2 <- n1PDF.Waldss(sim$RT[is.in2],v=v[r2],ts=ts,TRIALS=TRIALS[is.in2],
#                    B=B[r2],A=A[r2],t0,t0sg,SSD=SSD[is.in2],Si=2,tf=tf,gf=gf)
#   par(mfrow=c(1,3))
#   # red=black?
#   plot(x1c,dns1$'2'$y,pch=".",main="SSD=.1",ylab="Density",xlab="RT",type="l")
#   lines(x1e,dns1$'3'$y,lty=2)
#   lines(smooth.spline(sim$RT[is.in1 & sim$SSD==.1],
#                       d.r1[c(sim$SSD==.1)[is.in1]]),col="red")
#   lines(smooth.spline(sim$RT[is.in2 & sim$SSD==.1],d.r2[c(sim$SSD==.1)[is.in2]]),
#         lty=2,col="red")
#   # red=black?
#   plot(x2c,dns2$'2'$y,pch=".",main="SSD=1",ylab="Density",xlab="RT",type="l")
#   lines(x2e,dns2$'3'$y,lty=2)
#   lines(smooth.spline(sim$RT[is.in1 & sim$SSD==1],
#                       d.r1[c(sim$SSD==1)[is.in1]]),col="red")
#   lines(smooth.spline(sim$RT[is.in2 & sim$SSD==1],
#                       d.r2[c(sim$SSD==1)[is.in2]]),col="red",lty=2)
#   
#   print(tapply(is.na(sim$RT),sim$SSD,mean)) # empirical
#   tmp <- n1PDF.Waldss(rep(NA,n),v=v,A=A,B=B,t0=t0,t0sg=t0sg,SSD=SSD,Si=1,tf=tf,gf=gf,ts=ts,TRIALS=TRIALS)
#   print(mean(tmp[SSD==.1]))
#   print(mean(tmp[SSD==1]))
#   plot(TRIALS,tmp,pch=".",xlab="TRIALS",ylab="p(NA)",ylim=c(0,1))
#   lines(smooth.spline(TRIALS[SSD==.1],as.numeric(is.na(sim$RT)[SSD==.1])),col="red")
#   lines(smooth.spline(TRIALS[SSD==1],as.numeric(is.na(sim$RT)[SSD==1])),col="red")
# } else {
#   # Save simulated densities
#   r1 <- c(2,1,3)
#   d.r1 <- n1PDF.Waldss(rt=c(x1c,x2c),v=v[r1],B=B[r1],A=A[r1],t0=t0,t0sg=t0sg,
#     SSD=c(rep(.1,length(x1c)),rep(1,length(x2c))),Si=2,tf=tf,gf=gf)
#   r2 <- c(3,1,2)
#   d.r2 <- n1PDF.Waldss(rt=c(x1e,x2e),v=v[r2],B=B[r2],A=A[r2],t0=t0,t0sg=t0sg,
#     SSD=c(rep(.1,length(x1e)),rep(1,length(x2e))),Si=2,tf=tf,gf=gf)
#   # Plot simulated (black) and theoretical (red) densities
#   par(mfrow=c(1,2))
#   # red=black?
#   plot(x1c,dns1$'2'$y,type="l",main="SSD=.1",ylab="Density",xlab="RT",
#      ylim=c(0,max(dns1$'2'$y)))
#   lines(x1c,d.r1[1:length(x1c)],col="red")
#   lines(x1e,dns1$'3'$y,lty=2)
#   lines(x1e,d.r2[1:length(x1e)],col="red",lty=2)
#   # red=black?
#   plot(x2c,dns2$'2'$y,type="l",main="SSD=1",ylab="Density",xlab="RT",
#      ylim=c(0,max(dns2$'2'$y)))
#   lines(x2c,d.r1[(length(x2c)+1):(2*length(x2c))],col="red")
#   lines(x2e,dns2$'3'$y,lty=2)
#   lines(x2e,d.r2[(length(x2e)+1):(2*length(x2e))],col="red",lty=2)
# 
#   # p(Stop check)
#   print(tapply(is.na(sim$RT),sim$SSD,mean)) # empirical
#   print(n1PDF.Waldss(NA,v=v,B=B,A=A,t0=t0,t0sg=t0sg,SSD=.1,Si=1,tf=tf,gf=gf))
#   print(n1PDF.Waldss(NA,v=v,B=B,A=A,t0=t0,t0sg=t0sg,SSD=1,Si=1,tf=tf,gf=gf))
# }
# }
}

####################### LBA stop signal ----
{
# NB1: no st0
  
# NB2: TRIALS effect on B (threshold), and values < 0 set to 0 

rLBAss <- function (n, v, sv, B, A, t0, t0sg, tf=0, gf=0, ts = 0,
                    SSD=Inf, TRIALS = NA, staircase=NA,posdrift=TRUE) 
# Race among length(v) accumulators (if v a vector), 
# or dim(v)[1] (if a matrix), first of which is a stop accumulator.
# Acts the same as rlba.norm except NA returned for RT when winner = 1 
# AND USES B PARAMETERIZATION
# Optional SSD argument can be used to adjust start time for first
# accumulator. SSD can be a scalar or vector length n; output has an SSD column 
# For trials with winning first accumulator RT and R set to NA. 
# tf = trigger failure probability, gf = go failure probability
# If any !is.na in staircase runs a staircase
# t0 is a scalar with the standard interpritaiton for GO accumulators. 
# Definition of t0sg (a non-negative scalar) depends on whether response 
# production time is assumed to be ballistic or not.  
# If it is ballistic t0sg = stop encoding - go encoding time + t0 
# If if it is NOT ballistic, t0sg = stop encoding 
# IN BOTH CASES t0sg < 0 IS NOT ALLOWED
# ts = slope of slowing (speeding if negative) over TRIALS, meanlog - ts*TRIALS
# This has a linear effect on mean and sd

{
  if ( t0sg < 0 ) stop("t0sg cannot be less than zero")  
  
  if ( length(SSD)==1 ) SSD <- rep(SSD,n)
  if ( any(is.na(SSD)) || length(SSD) != n )
    stop("SSD cannot have NAs and must be a scalar or same length as n")
 
  n_acc <- ifelse(is.null(dim(v)),length(v),dim(v)[1])

  # t0sg -> sg for stop accumulator, relative to 0 for go accumulators
  t0S <- matrix(rep(c(t0sg-t0[1],rep(0,n_acc-1)),length.out=n*n_acc),nrow=n_acc)
  
  if ( !is.matrix(v) ) v <- matrix(rep(v,n),nrow=n_acc)
  if ( !is.matrix(sv) ) sv <- matrix(rep(sv,n),nrow=n_acc)
  if ( !is.matrix(B) ) B <- matrix(rep(B,n),nrow=n_acc)
  if ( !is.matrix(A) ) A <- matrix(rep(A,n),nrow=n_acc)
  
  if ( !any(is.na(TRIALS)) ) {
    if (length(TRIALS)!=n)
      stop("TRIALS must have length n")
    B[-1,] <- B[-1,] + rep(ts*TRIALS,each=n_acc-1)
    B[B<0] <- 0
  }
  b <- B+A
    
  if ( gf > 0 ) # Setup for GO failure
    is.gf <- as.logical(rbinom(length(SSD),1,gf)) else
    is.gf <- logical(length(SSD))
  
  if ( all(!is.finite(SSD)) ) {              # ALL GO
    out <- rlba.norm(n,mean_v=v[-1,,drop=FALSE],sd_v=sv[-1,,drop=FALSE],
      b=b[-1,,drop=FALSE],A=A[-1,,drop=FALSE],t0=t0,posdrift=posdrift)
    out$response <- out$response+1
  } else {                                   # SOME STOP
    if ( any(is.na(staircase)) ) {           # STOP fixed SSD
      # add SSD to stop accumulator
      t0S[1,] <- t0S[1,] + SSD 
      out <- rlba.norm(n,mean_v=v,sd_v=sv,b=b,A=A,t0=t0S,posdrift=posdrift)
      if ( tf>0 ) {
        is.tf <- logical(length(SSD))
        is.tf[is.finite(SSD)][as.logical(rbinom(sum(is.finite(SSD)),1,tf))] <- TRUE  
        if ( any(is.tf) ) { 
          out[is.tf,] <- rlba.norm(sum(is.tf),
            mean_v=v[-1,is.tf,drop=FALSE],sd_v=sv[-1,is.tf,drop=FALSE],
            b=b[-1,is.tf,drop=FALSE],A=A[-1,is.tf,drop=FALSE],
            t0=0,posdrift=posdrift)
          out[is.tf,"response"] <- out[is.tf,"response"]+1
        }
      }
    } else {                                 # STOP, staircase
      if ( !is.numeric(staircase) | length(staircase)!=1 )
        stop("Staircase must be a numeric vector of length 1 specifying the step.")
      SSDi <- SSD[is.finite(SSD)][1] # begining SSD 
      dt <- rlba.norm(n,mean_v=v,sd_v=sv,b=b,A=A,t0=t0S,posdrift=posdrift,return.ttf=TRUE)
      # Setup
      winner <- numeric(n)
      for ( i in c(1:n) ) {
        if ( !is.finite(SSD[i]) )   # not staircase
          dt[1,i] <- dt[1,i] + SSD[i] else
          dt[1,i] <- dt[1,i] + SSDi # staircase
        if ( runif(1)<tf ) # Trigger failure
          winner[i] <- which.min(dt[2:n_acc,i])+1 else
          winner[i] <- which.min(dt[,i])
        if (is.gf[i]) winner[i] <- 1
        if ( is.finite(SSD[i]) ) { # update staircase
          SSD[i] <- SSDi
          if ( winner[i]==1 ) 
            SSDi <- SSDi + staircase else
            SSDi <- SSDi - staircase
            if (SSDi<1e-10) SSDi <- 0
        }
      }
      out <- data.frame(rt=dt[cbind(winner,1:n)],response=winner)
    }
    out$rt <- out$rt + t0 # Add t0 for go responses
  }
  names(out) <- c("RT","R")
  out[out$R==1,"RT"] <- NA
  if ( gf > 0 ) {
    out$RT[is.gf] <- NA
    out$R[is.gf] <- 1
  }
  if ( any(is.na(TRIALS)) ) cbind.data.frame(out,SSD=SSD) else
                            cbind.data.frame(out,SSD=SSD,TRIALS=TRIALS)
}
 



n1PDF.LBAss <- function(rt,v,sv,B,A,t0,t0sg,tf=0,gf=0,ts=0,
                        SSD=Inf,TRIALS=NA,Si,posdrift=TRUE)
# Same as n1PDFfixedt0.norm except SSD is either a scalar or vector of length(rt)
# stop accumulator must have name "NR". SSD is subtracted stop accumulator time
# and dt=NA done by integration.
#
# USES B PARAMETERIZATION
#
# tf= probabiliy of trigger failure, where
# L = trigger fail & respond + trigger and respond + trigger and no-response
#   = tf*L(N-1)+(1-tf)[L(N)+p(S)],
# L(N-1) = choice race likelihood (no stop accumulator), 
# L(N) = full N unit race likelihood given they did respond, 
# p(S) probability of stop winning
#
# gf = probabiliy of go failure. 
# On go trials:   L = go fail (so no response) + go and L above 
# L = gf + (1-gf)*[tf*L(N-1)+(1-tf)[L(N)+p(S)]]  or similarly
# L =    [ p(non-response) ]    +           [ p(response) ] 
#   = [ gf + (1-gf)(1-tf)p(S) ] + [ (1-gf){(tf*Ln(n-1) + (1-tf)*L(N))} ]
#
# NB:rt is NOT decision time, but rather full RT as t0 has to be passed
#    in order to include properly in cases where RT is NA (i.e., sucessful stop)
#
# Definition of t0sg (a non-negative scalar) depends on whether response 
# production time is assumed to be ballistic or not.  
# If it is ballistic t0sg = stop encoding - go encoding time + t0 
# If if it is NOT ballistic, t0sg = stop encoding 
# IN BOTH CASES t0sg < 0 IS NOT ALLOWED (zero likelihood returned)


{
  
  stopfn <- function(t,vj,svj,bj,Aj,t0,t0sg,SSD,Si,posdrift=TRUE) 
  {
    # d = s-g = tD-t0(GO), then add SSDstart time to get 
    # start time go - start time stop, i.e., finishing time advantage for GO
    t0S <- rep(0,length(vj)) # Set relative to stop accumulator finish time
    t0S[-Si] <- t0S[-Si]+t0sg-t0+SSD   
    # subtracting min(t0S) keeps all times positive
    dt <- matrix(rep(t,each=length(vj)),nrow=length(vj))+t0S-min(t0S)
    i <- c(Si,c(1:length(vj))[-Si])
    n1PDFfixedt0.norm(dt[i,,drop=FALSE],mean_v=vj[i],sd_v=svj[i],b=bj[i],A=Aj[i],
      posdrift=posdrift)
  }

  # NOTE: t0 is not subtracted when making dt but passed to handle RT=NA case
  
  # Bad t0sg
  if (t0sg<0) return(rep(0,length(rt)))
  
  if ( length(SSD)==1 ) SSD <- rep(SSD,length(rt))
  if (length(SSD) != length(rt))
    stop("SSD must be a scalar or same length as rt")
  n_acc <- ifelse(is.null(dim(v)),length(v),dim(v)[1])
  
  rt <- matrix(rep(rt,each=n_acc),nrow=n_acc)
  is.stop <- is.na(rt[1,])  
  
  if (!is.matrix(v)) v <- matrix(rep(v,dim(rt)[2]),nrow=n_acc)
  if (!is.matrix(sv)) sv <- matrix(rep(sv,dim(rt)[2]),nrow=n_acc)
  if (!is.matrix(B)) B <- matrix(rep(B,dim(rt)[2]),nrow=n_acc)
  if (!is.matrix(A)) A <- matrix(rep(A,dim(rt)[2]),nrow=n_acc)
  
  if ( any(is.na(TRIALS)) | ts == 0 ) { 
    p <- SSD[is.stop]
    pj <- c(1:sum(is.stop))[!duplicated(p)] # index of unique SSD
  } else {
    B[-Si,] <- B[-Si,] + ts*TRIALS
    p <- apply(
        rbind(B[,is.stop,drop=FALSE],SSD[is.stop]),
      2,paste,collapse="")
    pj <- c(1:sum(is.stop))[!duplicated(p)] # index of unique p and SSD
  }
  b <- B+A
  
  if ( any(!is.stop) ) 
  {
    rt[Si,!is.stop] <- rt[Si,!is.stop] - t0sg - SSD[!is.stop] 
    rt[-Si,!is.stop] <- rt[-Si,!is.stop]-t0 
    if ( tf > 0 ) 
    {
      rt[1,!is.stop] <- (1-gf)*(
        tf*n1PDFfixedt0.norm(rt[-Si,!is.stop,drop=FALSE],
          mean_v=v[-Si,!is.stop,drop=FALSE],sd_v=sv[-Si,!is.stop,drop=FALSE],
          A=A[-Si,!is.stop,drop=FALSE],b=b[-Si,!is.stop,drop=FALSE],posdrift=posdrift) +
        (1-tf)*n1PDFfixedt0.norm(rt[,!is.stop,drop=FALSE],
          mean_v=v[,!is.stop,drop=FALSE],sd_v=sv[,!is.stop,drop=FALSE],
          b=b[,!is.stop,drop=FALSE],A=A[,!is.stop,drop=FALSE],posdrift=posdrift)
      )
    } else 
      rt[1,!is.stop] <- (1-gf)*n1PDFfixedt0.norm(dt=rt[,!is.stop,drop=FALSE],
        mean_v=v[,!is.stop,drop=FALSE],sd_v=sv[,!is.stop,drop=FALSE],
        b=b[,!is.stop,drop=FALSE],A=A[,!is.stop,drop=FALSE],posdrift=posdrift)
  }
  
  if ( any(is.stop) ) for (j in pj) {
    if ( !is.finite(SSD[j]) ) tmp <- 0 else
      tmp <- my.integrate(f=stopfn,lower=0,vj=v[,j],svj=sv[,j],
        bj=b[,j],Aj=A[,j],t0=t0,t0sg=t0sg,SSD=SSD[j],Si=Si)
     rt[1,is.stop][p %in% p[j]] <- gf +(1-gf)*(1-tf)*tmp
  }
  rt[1,]
}


# VERY EXTENSIVE TESTING WITH Two different SSDs
{
# # ########### TWO ACCUMULATOR CASE
# {
# n=1e4
# # n=10
# v=c(.5,1); B=c(1,1); A=c(1,1); sv=c(1,1)
# SSD = rep(c(1,10)/10,each=n/2)
# 
# # Run one of the follwing two lines
# do.trials=FALSE
# do.trials = TRUE # requires very differnet plotting check, can be SLOW!
# 
# #### RUN ONE OF THE FOLLOWING THREE LINES, all assume .2s go Ter
# t0=.2; t0sg= 0  # minimum possible value of t0sg, stop encoding .2 less than go
# t0=.2; t0sg=.2  # equal stop and go enconding times
# t0=.2; t0sg=.4  # stop .2 slower than go
# 
# ### RUN ONE OF THE FOLLOWING FOUR LINES
# # Without trigger failure or go failure
# tf=0; gf=0
# # With trigger failure, no go failure
# tf=.1;gf=0
# # Without trigger failure, with go failure
# tf=0; gf=.1
# # With trigger failure and go failure
# tf=.1;gf=.1
# 
# if (do.trials) {
#   ts=.5; TRIALS=log10(seq(1,10,length.out=n)) # 1..10 natural so 0-1 on log
#   TRIALS <- as.vector(t(matrix(TRIALS,nrow=2))) # interleave SSDs
#   # Plot slowing in GO (usually nice and linear, up to smooting overfitting)
#   sim.go <- rLBAss(n=n,v=v,sv=sv,B=B,A=A,t0=t0,t0sg=t0sg,tf=tf,gf=gf,SSD=SSD,TRIALS=TRIALS,ts=ts)
#   is.in <- !is.na(sim.go$RT) # in case go failure
#   plot(smooth.spline(TRIALS[is.in],sim.go$RT[is.in]),ylab="Smooth",xlab="TRIALS",type="l")
# } else {TRIALS=NA;ts=0}
# 
# # Simulate stop trials
# sim <- rLBAss(n=n,v=v,sv=sv,B=B,A=A,t0=t0,t0sg=t0sg,tf=tf,gf=gf,SSD=SSD,TRIALS=TRIALS,ts=ts)
# 
# # Plot densities
# par(mfrow=c(1,2))
# dns1 <- plot.cell.density(sim[sim$SSD==.1,],xlim=c(0,7),save.density=TRUE,main="SSD=.1")
# dns2 <- plot.cell.density(sim[sim$SSD!=.1,],xlim=c(0,7),save.density=TRUE,main="SSD=1")
# x1c <- dns1$'2'$x; x2c <- dns2$'2'$x
# 
# # Signal respond RT
# dat <- sim; dat <- dat[!is.na(dat$RT),]; dat$R <- factor(as.character(dat$R))
# round(tapply(dat$RT,dat[,c("R","SSD")],mean),2)
# 
# if (do.trials) {
#   tmp <- n1PDF.LBAss(sim$RT[!is.na(sim$RT)],v=v[2:1],sv=sv[2:1],B=B[2:1],A=A[2:1],t0=t0,t0sg=t0sg,
#     ts=ts,TRIALS=TRIALS[!is.na(sim$RT)],SSD=SSD[!is.na(sim$RT)],Si=2,tf=tf,gf=gf)
#   par(mfrow=c(1,2))
#   # red=black?
#   plot(x1c,dns1$'2'$y,pch=".",main="SSD=.1",ylab="Density",xlab="RT")
#   lines(smooth.spline(sim$RT[!is.na(sim$RT) & SSD==.1],
#    tmp[c(SSD==.1)[!is.na(sim$RT)]]),col="red")
#   # red=black?
#   plot(x2c,dns2$'2'$y,pch=".",main="SSD=1",ylab="Density",xlab="RT")
#   lines(smooth.spline(sim$RT[!is.na(sim$RT) & SSD==1],
#     tmp[c(SSD==1)[!is.na(sim$RT)]]),col="red")
#   print(tapply(is.na(sim$RT),sim$SSD,mean)) # empirical
#   tmp <- n1PDF.LBAss(rep(NA,n),v=v,sv=sv,B=B,A=A,t0=t0,t0sg=t0sg,
#     SSD=SSD,Si=1,tf=tf,gf=gf,ts=ts,TRIALS=TRIALS)
#   print(mean(tmp[SSD==.1]))
#   print(mean(tmp[SSD==1]))
#   plot(TRIALS,tmp,pch=".",xlab="TRIALS",ylab="p(NA)",ylim=c(0,1))
#   lines(smooth.spline(TRIALS[SSD==.1],as.numeric(is.na(sim$RT)[SSD==.1])),col="red")
#   lines(smooth.spline(TRIALS[SSD==1],as.numeric(is.na(sim$RT)[SSD==1])),col="red")
# } else {
#   # Save simulated densities
#   r1 <- c(2,1)
#   d.r1 <- n1PDF.LBAss(rt=c(x1c,x2c),v=v[r1],sv=sv[r1],B=B[r1],A=A[r1],t0=t0,t0sg=t0sg,
#     SSD=c(rep(.1,length(x1c)),rep(1,length(x2c))),Si=2,tf=tf,gf=gf)
#   # Plot simulated (black) and theoretical (red) densities
#   par(mfrow=c(1,2))
#   # red=black?
#   plot(x1c,dns1$'2'$y,type="l",main="SSD=.1",ylab="Density",xlab="RT",
#      ylim=c(0,max(dns1$'2'$y)))
#   lines(x1c,d.r1[1:length(x1c)],col="red")
#   # red=black?
#   plot(x2c,dns2$'2'$y,type="l",main="SSD=1",ylab="Density",xlab="RT",
#      ylim=c(0,max(dns2$'2'$y)))
#   lines(x2c,d.r1[(length(x2c)+1):(2*length(x2c))],col="red")
# 
#   # p(Stop check)
#   print(tapply(is.na(sim$RT),sim$SSD,mean)) # empirical
#   print(n1PDF.LBAss(NA,v=v,sv=sv,A=A,B=B,t0=t0,t0sg=t0sg,SSD=.1,Si=1,tf=tf,gf=gf))
#   print(n1PDF.LBAss(NA,v=v,sv=sv,A=A,B=B,t0=t0,t0sg=t0sg,SSD=1,Si=1,tf=tf,gf=gf))
# }
# 
# }
# 
# ########### THREE ACCUMULATOR CASE
# {
# n=1e4
# v=c(.5,1,.5); B=c(1,1,1); A=c(1,1,1); sv=c(1,1,1)
# SSD = rep(c(1,10)/10,each=n/2)
# 
# do.trials=FALSE
# do.trials = TRUE # requires very differnet plotting check, can be SLOW!
# 
# #### RUN ONE OF THE FOLLOWING THREE LINES, all assume .2s go Ter
# t0=.2; t0sg= 0  # minimum possible value of t0sg, stop encoding .2 less than go
# t0=.2; t0sg=.2 # equal stop and go enconding times
# t0=.2; t0sg=.4 # stop .2 slower than go
# 
# ### RUN ONE OF THE FOLLOWING FOUR LINES
# # Without trigger failure or go failure
# tf=0; gf=0
# # With trigger failure, no go failure
# tf=.1;gf=0
# # Without trigger failure, with go failure
# tf=0; gf=.1
# # With trigger failure and go failure
# tf=.1;gf=.1
# 
# if (do.trials) {
#   ts=.5; TRIALS=log10(seq(1,10,length.out=n)) # 1..10 natural so 0-1 on log
#   TRIALS <- as.vector(t(matrix(TRIALS,nrow=2))) # interleave SSDs
#   # Plot slowing in GO (usually nice and linear, up to smooting overfitting)
#   sim.go <- rLBAss(n=n,v=v,sv=sv,B=B,A=A,t0=t0,t0sg=t0sg,tf=tf,gf=gf,TRIALS=TRIALS,ts=ts)
#   is.in <- !is.na(sim.go$RT) # in case go failure
#   plot(smooth.spline(TRIALS[is.in],sim.go$RT[is.in]),ylab="Smooth",xlab="TRIALS",type="l")
# } else {TRIALS=NA;ts=0}
# 
# # Simulate stop trials
# sim <- rLBAss(n=n,v=v,sv=sv,B=B,A=A,t0=t0,t0sg=t0sg,tf=tf,gf=gf,TRIALS=TRIALS,ts=ts,SSD=SSD)
# 
# 
# par(mfrow=c(1,2))
# dns1 <- plot.cell.density(sim[sim$SSD==.1,],xlim=c(0,7),save.density=TRUE,main="SSD=.1")
# dns2 <- plot.cell.density(sim[sim$SSD!=.1,],xlim=c(0,7),save.density=TRUE,main="SSD=1")
# x1c <- dns1$'2'$x; x2c <- dns2$'2'$x
# x1e <- dns1$'3'$x; x2e <- dns2$'3'$x
# 
# # Signal respond RT
# dat <- sim; dat <- dat[!is.na(dat$RT),]; dat$R <- factor(as.character(dat$R))
# round(tapply(dat$RT,dat[,c("R","SSD")],mean),2)
# 
# if (do.trials) {
#   r1 <- c(2,1,3)
#   is.in1 <- !is.na(sim$RT) & sim$R==2
#   d.r1 <- n1PDF.LBAss(sim$RT[is.in1],v=v[r1],sv=sv[r1],ts=ts,TRIALS=TRIALS[is.in1],
#           B=B[r1],A=A[r1],t0=t0,t0sg=t0sg,SSD=SSD[is.in1],Si=2,tf=tf,gf=gf)
#   r2 <- c(3,1,2)
#   is.in2 <- !is.na(sim$RT) & sim$R==3
#   d.r2 <- n1PDF.LBAss(sim$RT[is.in2],v=v[r2],sv=sv[r2],ts=ts,TRIALS=TRIALS[is.in2],
#                    B=B[r2],A=A[r2],t0,t0sg,SSD=SSD[is.in2],Si=2,tf=tf,gf=gf)
#   par(mfrow=c(1,3))
#   # red=black?
#   plot(x1c,dns1$'2'$y,pch=".",main="SSD=.1",ylab="Density",xlab="RT",type="l")
#   lines(x1e,dns1$'3'$y,lty=2)
#   lines(smooth.spline(sim$RT[is.in1 & sim$SSD==.1],
#                       d.r1[c(sim$SSD==.1)[is.in1]]),col="red")
#   lines(smooth.spline(sim$RT[is.in2 & sim$SSD==.1],d.r2[c(sim$SSD==.1)[is.in2]]),
#         lty=2,col="red")
#   # red=black?
#   plot(x2c,dns2$'2'$y,pch=".",main="SSD=1",ylab="Density",xlab="RT",type="l")
#   lines(x2e,dns2$'3'$y,lty=2)
#   lines(smooth.spline(sim$RT[is.in1 & sim$SSD==1],
#                       d.r1[c(sim$SSD==1)[is.in1]]),col="red")
#   lines(smooth.spline(sim$RT[is.in2 & sim$SSD==1],
#                       d.r2[c(sim$SSD==1)[is.in2]]),col="red",lty=2)
#   
#   print(tapply(is.na(sim$RT),sim$SSD,mean)) # empirical
#   tmp <- n1PDF.LBAss(rep(NA,n),v=v,sv=sv,A=A,B=B,t0=t0,t0sg=t0sg,SSD=SSD,Si=1,tf=tf,gf=gf,ts=ts,TRIALS=TRIALS)
#   print(mean(tmp[SSD==.1]))
#   print(mean(tmp[SSD==1]))
#   plot(TRIALS,tmp,pch=".",xlab="TRIALS",ylab="p(NA)",ylim=c(0,1))
#   lines(smooth.spline(TRIALS[SSD==.1],as.numeric(is.na(sim$RT)[SSD==.1])),col="red")
#   lines(smooth.spline(TRIALS[SSD==1],as.numeric(is.na(sim$RT)[SSD==1])),col="red")
# } else {
#   # Save simulated densities
#   r1 <- c(2,1,3)
#   d.r1 <- n1PDF.LBAss(rt=c(x1c,x2c),v=v[r1],sv=sv[r1],B=B[r1],A=A[r1],t0=t0,t0sg=t0sg,
#     SSD=c(rep(.1,length(x1c)),rep(1,length(x2c))),Si=2,tf=tf,gf=gf)
#   r2 <- c(3,1,2)
#   d.r2 <- n1PDF.LBAss(rt=c(x1e,x2e),v=v[r2],sv=sv[r2],B=B[r2],A=A[r2],t0=t0,t0sg=t0sg,
#     SSD=c(rep(.1,length(x1e)),rep(1,length(x2e))),Si=2,tf=tf,gf=gf)
#   # Plot simulated (black) and theoretical (red) densities
#   par(mfrow=c(1,2))
#   # red=black?
#   plot(x1c,dns1$'2'$y,type="l",main="SSD=.1",ylab="Density",xlab="RT",
#      ylim=c(0,max(dns1$'2'$y)))
#   lines(x1c,d.r1[1:length(x1c)],col="red")
#   lines(x1e,dns1$'3'$y,lty=2)
#   lines(x1e,d.r2[1:length(x1e)],col="red",lty=2)
#   # red=black?
#   plot(x2c,dns2$'2'$y,type="l",main="SSD=1",ylab="Density",xlab="RT",
#      ylim=c(0,max(dns2$'2'$y)))
#   lines(x2c,d.r1[(length(x2c)+1):(2*length(x2c))],col="red")
#   lines(x2e,dns2$'3'$y,lty=2)
#   lines(x2e,d.r2[(length(x2e)+1):(2*length(x2e))],col="red",lty=2)
# 
#   # p(Stop check)
#   print(tapply(is.na(sim$RT),sim$SSD,mean)) # empirical
#   print(n1PDF.LBAss(NA,v=v,sv=sv,B=B,A=A,t0=t0,t0sg=t0sg,SSD=.1,Si=1,tf=tf,gf=gf))
#   print(n1PDF.LBAss(NA,v=v,sv=sv,B=B,A=A,t0=t0,t0sg=t0sg,SSD=1,Si=1,tf=tf,gf=gf))
# }
# 
}

}


############################################## ----
# Only random functions for models that mix parameters (mixing is done in
# likelihood.dmc for likelihood).

# LBA n-choice 2 threhsold
# lnorm (Uniform / Lognormal) n-choice 2 threhsold
 
################### LBA n-choice 2 threhsold ----

rlba.normBp2 <- function(n,A,b1,b2,pb2,t0,mean_v,sd_v,st0,
        posdrift=TRUE) {
  
  n2 <- sum(rbinom(n,1,pb2))
  out <- matrix(nrow=n,ncol=2)
  dimnames(out) <- list(NULL,c("rt","response"))
  out <- data.frame(out)
  if (n2<n) out[1:(n-n2),] <- rlba.norm(n-n2,A=A,b=b1,t0=t0,mean_v=mean_v,sd_v=sd_v,st0=st0[1],
        posdrift = posdrift)
  if (n2>0) out[-c(1:(n-n2)),] <- rlba.norm(n2,A=A,b=b2,t0=t0,mean_v=mean_v,sd_v=sd_v,st0=st0[1],
        posdrift = posdrift)
  out
}

################### lnorm (Uniform / Lognormal) n-choice 2 threhsold ----

rlba_lnormBp2 <- function(n,A,b1,b2,pb2,t0,meanlog_v,sdlog_v,st0) {
  n2 <- sum(rbinom(n,1,pb2))
  out <- matrix(nrow=n,ncol=2)
  dimnames(out) <- list(NULL,c("rt","response"))
  out <- data.frame(out)
  if (n2<n) out[1:(n-n2),] <- rlba_lnorm(n-n2,A=A,b=b1,t0,meanlog_v,sdlog_v,st0=st0[1])
  if (n2>0) out[-c(1:(n-n2)),] <- rlba_lnorm(n2,A=A,b=b2,t0,meanlog_v,sdlog_v,st0=st0[1])
  out
}

